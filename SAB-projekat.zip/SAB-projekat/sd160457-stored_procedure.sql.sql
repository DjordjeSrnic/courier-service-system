use CourierService
go

create procedure PR_Grant_Request
@username varchar(100)
as begin

	declare @licence_number varchar(100)

	if not exists (select * from Request where Username = @username) return 0

	select @licence_number = LicenceNumber from Request where Username = @username

	begin transaction [Tran1]
	begin try

		insert into Courier(Username, LicenceNumber, NumDeliveries, Profit, Status) values (@username, @licence_number, 0,0,0)

		delete from Request where Username = @username

	commit transaction [Tran1]
	end try
	begin catch
		rollback transaction [Tran1]
		return 0
	end catch

	return 1
end

go