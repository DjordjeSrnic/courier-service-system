use CourierService
go

create trigger TR_TransportOffer_Accept
on AcceptedOffer for insert, update
as begin

	declare @i cursor
	declare @idOffer int
	declare @idPackage int
	declare @username varchar(100)
	declare @addressTo int
	declare @addressFrom int
	declare @weight decimal(10,3)
	declare @idInfo int 
	declare @percentage decimal(10,3)

	declare @initPrice decimal(10,3)
	declare @price decimal(10,3)
	declare @xTo int
	declare @yTo int
	declare @xFrom int
	declare @yFrom int
	declare @distance decimal(10,3)
	declare @finalPrice decimal (10,3)

	set @i = cursor for select IdOffer from inserted

	open @i

	fetch from @i into @idOffer

	while @@FETCH_STATUS=0
	begin
		select @idPackage = IdPackage from Offer where Id = @idOffer

		if exists(select Id from Package where Id = @idPackage)
		begin
			delete from Offer where IdPackage = @idPackage and NOT Id = @idOffer

			declare @kursor cursor
			set @kursor = cursor for select addressTo, addressFrom, Weight, PackageType from Package where Id = @idPackage
			open @kursor
			fetch next from @kursor into @addressTo, @addressFrom, @weight, @idInfo 

			select @initPrice = InitialPrice, @price = Price from PackageInfo where PackageType = @idInfo
			select @xFrom = xCoord, @yFrom = yCoord from address where Id = @addressFrom
			select @xTo = xCoord, @yTo = yCoord from address where Id = @addressTo
			select @distance = SQRT(POWER(@xTo - @xFrom,2) + POWER(@yTo - @yFrom,2))
			select @finalPrice = (@initPrice +@weight*@price)*@distance

			update Package set Price = @finalPrice, Status = 1 where Id = @idPackage

			close @kursor
			deallocate @kursor

		end
		else delete from AcceptedOffer where IdOffer = @idOffer

		fetch from @i into @idOffer
	end

	close @i
	deallocate @i

end
go

create trigger TR_TransportOffer_Create
on Package for insert, update
as begin

	declare @i cursor
	declare @idOffer int
	declare @idPackage int
	declare @username varchar(100)
	declare @addressTo int
	declare @addressFrom int
	declare @weight decimal(10,3)
	declare @idInfo int 
	declare @percentage decimal(10,3)

	declare @initPrice decimal(10,3)
	declare @price decimal(10,3)
	declare @xTo int
	declare @yTo int
	declare @xFrom int
	declare @yFrom int
	declare @distance decimal(10,3)
	declare @finalPrice decimal (10,3)

	set @i = cursor for select Id from inserted

	open @i

	fetch from @i into @idPackage

	while @@FETCH_STATUS=0
	begin

		insert into Offer(IdPackage) values (@idPackage)

		fetch from @i into @idOffer
	end

	close @i
	deallocate @i

end