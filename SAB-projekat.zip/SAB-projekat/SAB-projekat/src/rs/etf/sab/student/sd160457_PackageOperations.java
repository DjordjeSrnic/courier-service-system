/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.*;

/**
 *
 * @author Djordje
 */
public class sd160457_PackageOperations implements PackageOperations {

    private Connection con;
    
    public sd160457_PackageOperations() {
        this.con = DB.getInstance().getConnection();
    }
    
    @Override
    public int insertPackage(int addressFrom, int addressTo, String userName, int packageType, BigDecimal weight) {
        String query = "INSERT INTO Package(AddressFrom, AddressTo, Weight, Status, PackageType, Sender) VALUES(?,?,?,?,?,?)";
        
        try (PreparedStatement stmt = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);) {
            Time time = new Time(0L);
            time.setTime(new java.util.Date().getTime());
            
            stmt.setInt(1, addressFrom);
            stmt.setInt(2, addressTo);
            stmt.setDouble(3, weight.doubleValue());
            stmt.setInt(4, 0);
            stmt.setInt(5, packageType);
            stmt.setString(6, userName);
            int ret = -1; 
            stmt.executeUpdate();
            ResultSet res = stmt.getGeneratedKeys();
            if (res.next()) {
                ret = res.getInt(1);
                System.out.println("PackageRowId " + ret);
            }
            return ret;
        } catch (SQLException e) {
            Logger.getLogger(sd160457_PackageOperations.class.getName()).log(Level.SEVERE, null, e);
        }
        
        return -1;
    }

    @Override
    public boolean acceptAnOffer(int packageId) {
        String query1 = "SELECT * FROM Offer WHERE IdPackage = ?";
        String query2 = "DELETE Offer WHERE Id = ?";
        String query3 = "INSERT INTO AcceptedOffer(IdOffer, AcceptedTime) VALUES (?,?)";
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);
             PreparedStatement stmt3 = con.prepareStatement(query3);) {
            
            stmt1.setInt(1, packageId);
            ResultSet rs1 = stmt1.executeQuery();
            if (rs1.next() == false)
                return false;
            
            int idOffer = rs1.getInt("Id");
            
            stmt3.setInt(1, idOffer);
            stmt3.setDate(2, (Date) new java.sql.Date(Calendar.getInstance().getTimeInMillis()));
            int ret = stmt3.executeUpdate();
            if (ret == 1) {
                System.out.println("ACCEPT OFFER");
                return true;
            }
            else 
                return false;
        } catch (SQLException e) {
            Logger.getLogger(sd160457_PackageOperations.class.getName()).log(Level.SEVERE, null, e);
        }

        return false;
    }

    @Override
    public boolean rejectAnOffer(int packageId) {
        String query1 = "SELECT * FROM Offer WHERE IdPackage = ?";
        String query2 = "DELETE Offer WHERE Id = ?";
        String query3 = "INSERT INTO RejectedOffer(IdOffer) VALUES (?)";
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);
             PreparedStatement stmt3 = con.prepareStatement(query3);) {
            
            stmt1.setInt(1, packageId);
            ResultSet rs1 = stmt1.executeQuery();
            if (rs1.next() == false)
                return false;
            
            stmt3.setInt(1, packageId);
            int ret = stmt3.executeUpdate();
            if (ret == 1)
                return true;
            else 
                return false;
        } catch (SQLException e) {
            Logger.getLogger(sd160457_PackageOperations.class.getName()).log(Level.SEVERE, null, e);
        }

        return false;
    }

    @Override
    public List<Integer> getAllPackages() {
        String query ="SELECT * FROM Package ";  
        
        List<Integer> ret = new ArrayList<>();
        try (PreparedStatement stmt=con.prepareStatement(query);){
             ResultSet res=stmt.executeQuery();
             while(res.next()){
                 ret.add(res.getInt("Id"));
             }
         } catch (SQLException e) {
             Logger.getLogger(sd160457_PackageOperations.class.getName()).log(Level.SEVERE, null, e);
         }
         return ret;
    }

    @Override
    public List<Integer> getAllPackagesWithSpecificType(int type) {
        String query ="SELECT * FROM Package WHERE PackageType = ?";  
        
        List<Integer> ret = new ArrayList<>();
        try (PreparedStatement stmt=con.prepareStatement(query);){
             stmt.setInt(1, type);
             ResultSet res=stmt.executeQuery();
             while(res.next()){
                 ret.add(res.getInt("Id"));
             }
         } catch (SQLException e) {
             Logger.getLogger(sd160457_PackageOperations.class.getName()).log(Level.SEVERE, null, e);
         }
         return ret;
    }

    @Override
    public List<Integer> getAllUndeliveredPackages() {
        String query ="SELECT * FROM Package WHERE Status = 1 OR Status = 2";  
        
        List<Integer> ret = new ArrayList<>();
        try (PreparedStatement stmt=con.prepareStatement(query);){
             ResultSet res=stmt.executeQuery();
             while(res.next()){
                 ret.add(res.getInt("Id"));
             }
         } catch (SQLException e) {
             Logger.getLogger(sd160457_PackageOperations.class.getName()).log(Level.SEVERE, null, e);
         }
        
         return ret;
    }

    @Override
    public List<Integer> getAllUndeliveredPackagesFromCity(int cityId) {
        String query = "SELECT P.Id FROM Package P INNER JOIN "
                + "Address A ON P.AddressFrom = A.Id "
                + "WHERE A.IdCity = ? AND (Status = 1 OR Status = 2)"; 
        
        List<Integer> ret = new ArrayList<>();
        try (PreparedStatement stmt=con.prepareStatement(query);){
            stmt.setInt(1, cityId);
            ResultSet res=stmt.executeQuery();
            while(res.next()){
                ret.add(res.getInt(1));
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_PackageOperations.class.getName()).log(Level.SEVERE, null, e);
        }

        return ret;
    }

    @Override
    public List<Integer> getAllPackagesCurrentlyAtCity(int cityId) {
        String query1 ="SELECT P.Id FROM Package P INNER JOIN "
                + "Address A ON P.AddressFrom = A.Id "
                + "WHERE A.IdCity = ? AND P.Status <> 2 AND P.Status <> 3";  
        String query2 ="SELECT P.Id FROM Package P INNER JOIN "
                + "Address A ON P.AddressTo = A.Id "
                + "WHERE A.IdCity = ? AND P.Status = 3";  
        String query3 ="SELECT S.IdPackage FROM Stored S INNER JOIN "
                + "Stockroom ST ON S.IdStockroom = ST.Id "
                + "WHERE ST.IdCity = ?";  
        
        System.out.println("GET ALL PACKAGES CURRENTLY AT CITY " + cityId);
        List<Integer> ret = new ArrayList();
        try (PreparedStatement stmt1=con.prepareStatement(query1);
             PreparedStatement stmt2=con.prepareStatement(query2);
             PreparedStatement stmt3=con.prepareStatement(query3);){
             
            stmt1.setInt(1, cityId);
            ResultSet rs1 = stmt1.executeQuery();
            while(rs1.next()){
                System.out.println("PACKAGE: " + rs1.getInt(1));
                ret.add(rs1.getInt(1));
            }
            
            stmt2.setInt(1, cityId);
            ResultSet rs2 = stmt2.executeQuery();
            while(rs2.next()){
                System.out.println("PACKAGE: " + rs2.getInt(1));
                ret.add(rs2.getInt(1));
            }
            
            stmt3.setInt(1, cityId);
            ResultSet rs3 = stmt3.executeQuery();
            while(rs3.next()){
                System.out.println("PACKAGE: " + rs3.getInt(1));
                ret.add(rs3.getInt(1));
            }
             
         } catch (SQLException e) {
             Logger.getLogger(sd160457_PackageOperations.class.getName()).log(Level.SEVERE, null, e);
         }
        
         return ret;
    }

    @Override
    public boolean deletePackage(int packageId) {
        String query = "DELETE FROM Package WHERE Id = ? AND (Status = 0 OR Status = 4)";
        
        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, packageId);
            int ret = stmt.executeUpdate();
            if (ret == 1)
                return true;
            else
                return false;
        } catch (SQLException e) {
            Logger.getLogger(sd160457_PackageOperations.class.getName()).log(Level.SEVERE, null, e);
        }
        return false;
    }

    @Override
    public boolean changeWeight(int packageId, BigDecimal newWeight) {
        String query = "UPDATE Package SET Weight = ? WHERE Id = ? AND Status = 0";

        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setDouble(1, newWeight.doubleValue());
            stmt.setInt(2, packageId);
            int ret = stmt.executeUpdate();
            if (ret == 1)
                return true;
        } catch (SQLException e) {
            Logger.getLogger(sd160457_PackageOperations.class.getName()).log(Level.SEVERE, null, e);
        }

        return false;
    }

    @Override
    public boolean changeType(int packageId, int newType) {
        String query = "UPDATE Package SET PackageType = ? where Id = ? AND Status = 0";

        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, newType);
            stmt.setInt(2, packageId);
            int ret = stmt.executeUpdate();
            if (ret == 1)
                return true;
        } catch (SQLException e) {
            Logger.getLogger(sd160457_PackageOperations.class.getName()).log(Level.SEVERE, null, e);
        }

        return false;
    }

    @Override
    public int getDeliveryStatus(int packageId) {
        String query = "SELECT Status FROM Package WHERE Id = ?";
        
        System.out.println("CHECK DELIVERY STATUS FOR " + packageId);
        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, packageId);
            ResultSet res = stmt.executeQuery();
            
            if (res.next()) {
                System.out.println("DELIVERY STATUS: " + res.getInt(1));
                return res.getInt(1);
            } else
                return -1;
        } catch (SQLException e) {
            Logger.getLogger(sd160457_PackageOperations.class.getName()).log(Level.SEVERE, null, e);
        }

        return -1;
    }

    @Override
    public BigDecimal getPriceOfDelivery(int packageId) {
        String query = "SELECT Price FROM Package WHERE Id = ?";
        
        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, packageId);
            ResultSet res = stmt.executeQuery();
            if (res.next() == false || res.wasNull())
                return null;
            else
                return res.getBigDecimal("Price");

        } catch (SQLException e) {
            Logger.getLogger(sd160457_PackageOperations.class.getName()).log(Level.SEVERE, null, e);
        }

        return null;
    }

    @Override
    public int getCurrentLocationOfPackage(int packageId) {
        String query1 = "SELECT * FROM Trunk WHERE IdPackage = ?";
        String query2 = "SELECT ST.IdCity FROM Stored S INNER JOIN "
                + "Stockroom ST ON S.IdStockroom = ST.Id "
                + "WHERE S.IdPackage = ?";
        String query3 = "SELECT AddressTo FROM Package WHERE Id=? AND Status = 3";
        String query4 = "SELECT AddressFrom FROM Package WHERE Id=?";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);
             PreparedStatement stmt3 = con.prepareStatement(query3);
             PreparedStatement stmt4 = con.prepareStatement(query4);) {
            
            stmt1.setInt(1, packageId);
            ResultSet rs1 = stmt1.executeQuery();
            if (rs1.next() == true) {
                System.out.println("CURRENT LOCATION OF PACKAGE " + -1);
                return -1;
            }
            
            stmt2.setInt(1, packageId);
            ResultSet rs2 = stmt2.executeQuery();
            if (rs2.next() == true) {
                System.out.println("CURRENT LOCATION OF PACKAGE " + rs2.getInt(1));
                return rs2.getInt(1);
            }
            
            stmt3.setInt(1, packageId);
            ResultSet rs3 = stmt3.executeQuery();
            if (rs3.next() == true) {
                System.out.println("CURRENT LOCATION OF PACKAGE " + rs3.getInt(1));
                return rs3.getInt(1);
            }
            
            stmt4.setInt(1, packageId);
            ResultSet rs4 = stmt4.executeQuery();
            if (rs4.next() == true) {
                System.out.println("CURRENT LOCATION OF PACKAGE " + rs4.getInt(1));
                return rs4.getInt(1);
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_PackageOperations.class.getName()).log(Level.SEVERE, null, e);
        }

        return -1;
    }

    @Override
    public Date getAcceptanceTime(int packageId) {
        String query = "SELECT AcceptedTime FROM AcceptedOffer WHERE IdOffer = ?";
        
        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, packageId);
            ResultSet res = stmt.executeQuery();
            if (res.next() == false)
                return null;
            else
                return res.getDate("AcceptedTime");
        } catch (SQLException e) {
            Logger.getLogger(sd160457_PackageOperations.class.getName()).log(Level.SEVERE, null, e);
        }

        return null;
    }
    
}
