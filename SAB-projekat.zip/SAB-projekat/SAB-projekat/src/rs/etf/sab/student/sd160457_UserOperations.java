/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.*;

/**
 *
 * @author Djordje
 */
public class sd160457_UserOperations implements UserOperations {

    private Connection con;
    
    public sd160457_UserOperations() {
        this.con = DB.getInstance().getConnection();
    }
    
    @Override
    public boolean insertUser(String userName, String firstName, String lastName, String password, int idAddress) {
        String query1 = "SELECT * FROM [User] WHERE Username=? ";
        String query2 = "SELECT * FROM Address WHERE Id = ? ";
        String query3 = "INSERT INTO [User](Name, Surname, Username, Password, IdAddress, NumSent) VALUES (?,?,?,?,?,?) ";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);
             PreparedStatement stmt3 = con.prepareStatement(query3, Statement.RETURN_GENERATED_KEYS);) {
            
            if (!Character.isUpperCase(firstName.charAt(0))) {
                return false;
            }
            
            if (!Character.isUpperCase(lastName.charAt(0))) {
                return false;
            }
            
            if (password.length() < 8) {
                return false;
            }
            
            if (!password.matches(".*[a-z].*") || !password.matches(".*[A-Z].*") || !password.matches(".*[0-9].*") || !password.matches(".*[@#$%^&-+=_()].*")) {
                return false;
            }
            
            stmt1.setString(1, userName);
            ResultSet res1 = stmt1.executeQuery();
            
            if (res1.next() == true) {
                return false;
            }
            
            stmt2.setInt(1, idAddress);
            ResultSet res2 = stmt2.executeQuery();
            if (res2.next() == false){
                return false;
            }

            stmt3.setString(1, firstName);
            stmt3.setString(2, lastName);
            stmt3.setString(3, userName);
            stmt3.setString(4, password);
            stmt3.setInt(5, idAddress);
            stmt3.setInt(6, 0);
            int ret = stmt3.executeUpdate();
            
            if(ret!=0) {
                System.out.println("UserRow");
                return true;
            } else 
                return false;
        } catch (SQLException e) {
            Logger.getLogger(sd160457_UserOperations.class.getName()).log(Level.SEVERE, null, e);
            return false;
        }
    }

    @Override
    public boolean declareAdmin(String userName) {
        String query1 = "SELECT * FROM [User] WHERE Username=?";
        String query2 = "SELECT * FROM Administrator WHERE Username=?";
        String query3 = "INSERT INTO Administrator(Username) VALUES (?)";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);
             PreparedStatement stmt3 = con.prepareStatement(query3);
            ) {
            
            stmt1.setString(1, userName);
            ResultSet res1 = stmt1.executeQuery();
            if (res1.next() == false) {
                return false;
            }
            
            stmt2.setString(1, userName);
            ResultSet res2 = stmt2.executeQuery();
            if(res2.next()){
                return false;
            }
            
            stmt3.setString(1, userName);
            stmt3.executeUpdate();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(sd160457_UserOperations.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    @Override
    public int getSentPackages(String... userNames) {
        String query = "SELECT NumSent FROM [User] WHERE Username=?";
        int sent=0;
        boolean userExists=false;
        for(String user: userNames){
            try (PreparedStatement stmt = con.prepareStatement(query);) {
                stmt.setString(1, user);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    sent=+rs.getInt(1);
                    userExists=true;
                }
            } catch (SQLException ex) {
                Logger.getLogger(sd160457_UserOperations.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if(userExists==false) {
            return -1;
        }
        
        return sent;
    }

    @Override
    public int deleteUsers(String... userNames) {
        String query = "DELETE [User] WHERE Username=?";
        
        int ret=0;
        for (String user : userNames) {
            try (PreparedStatement ps = con.prepareStatement(query);) {
                ps.setString(1, user);
                ret += ps.executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(sd160457_UserOperations.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return ret;
    }

    @Override
    public List<String> getAllUsers() {
        String query = "SELECT * FROM [User] ";
        
        List<String> ret=new ArrayList<>();
        try (PreparedStatement stmt = con.prepareStatement(query);) {
            ResultSet res = stmt.executeQuery();
            while (res.next()) {
                ret.add(res.getString("Username"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(sd160457_UserOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
       return ret;
    }
    
}
