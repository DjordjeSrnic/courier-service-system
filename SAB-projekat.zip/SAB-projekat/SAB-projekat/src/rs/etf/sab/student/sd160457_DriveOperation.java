/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.util.Pair;
import rs.etf.sab.operations.*;

/**
 *
 * @author Djordje
 */
public class sd160457_DriveOperation implements DriveOperation {

    private static Connection con;
    
    public sd160457_DriveOperation() {
        this.con = DB.getInstance().getConnection();
    }
    
    static class Coordinates {
        int X;
        int Y;
        int address;

        public Coordinates(int X, int Y, int address) {
            this.X = X;
            this.Y = Y;
            this.address = address;
        }
        
        public int getX() {
            return X;
        }
        
        public int getY() {
            return Y;
        }
        
        public int getAddress() {
            return address;
        }
    }
    
    static class Edge {
        Coordinates A;
        Coordinates B;
        double distance;
        
        public Edge(Coordinates A, Coordinates B, double distance) {
            this.A = A;
            this.B = B;
            this.distance = distance;
        }

        public Coordinates getA() {
            return A;
        }

        public Coordinates getB() {
            return B;
        }

        public double getDistance() {
            return distance;
        }
    }
    
    @Override
    public boolean planingDrive(String courierUsername) {
        
        System.out.println("PLANNING DRIVE");
        String query0 = "SELECT V.LicencePlate, CT.Id, V.Capacity, U.IdAddress FROM Courier C INNER JOIN "
                + "[User] U ON C.Username = U.Username INNER JOIN "
                + "Address A ON A.Id = U.IdAddress INNER JOIN "
                + "City CT ON CT.Id = A.IdCity INNER JOIN "
                + "Stockroom S ON S.IdCity = CT.Id INNER JOIN "
                + "Parked P ON P.IdStockroom = S.Id INNER JOIN "
                + "Vehicle V ON V.LicencePlate = P.LicencePlate "
                + "WHERE C.Username = ? ";
        // Query za dodeljivanje vozila kuriru
        String query1 = "INSERT INTO Drives(Username, LicencePlate, IdAddress, TravelDistance) "
                + "VALUES(?,?,?,?) ";
        // Query za uklanjanje vozila sa parkinga
        String query2 = "DELETE FROM Parked "
                + "WHERE LicencePlate = ? ";
        // Query za dohvatanje svih paketa iz grada sortiranih rastuce po vremenu prihvatanja ponude
        String query3 = "SELECT P.Id, P.Weight, P.AddressFrom FROM Package P INNER JOIN "
                + "Address A ON P.AddressFrom = A.Id INNER JOIN "
                + "Offer O ON O.IdPackage = P.Id INNER JOIN "
                + "AcceptedOffer AO ON O.Id = AO.IdOffer "
                + "WHERE A.IdCity = ? AND P.Status = ? "
                + "ORDER BY AO.AcceptedTime ";
        // Dodaj paket u listu za dostavke
        String query4 = "INSERT INTO ToDeliver(IdPackage, IdAddress, Username) "
                + "VALUES(?,?,?) ";
        String query5 = "SELECT P.Id, P.Weight, S.IdAddress FROM Stockroom S INNER JOIN Stored ST "
                + "ON S.Id = ST.IdStockroom INNER JOIN Package P "
                + "ON ST.IdPackage = P.Id INNER JOIN Offer O "
                + "ON P.Id = O.IdPackage INNER JOIN AcceptedOffer AO "
                + "ON AO.IdOffer = O.Id "
                + "WHERE S.IdCity = ? "
                + "ORDER BY AO.AcceptedTime ";
        
        
        try (PreparedStatement stmt0 = con.prepareStatement(query0);
             PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);
             PreparedStatement stmt3 = con.prepareStatement(query3);
             PreparedStatement stmt4 = con.prepareStatement(query4);
             PreparedStatement stmt5 = con.prepareStatement(query5);) {
            
            // Dohvati vozilo, proveri da li postoji i ako postoji ukloni sa parkinga
            stmt0.setString(1, courierUsername);
            ResultSet rs0 = stmt0 .executeQuery();
            if (!rs0.next()) {
                return false;
            }
            String licencePlate = rs0.getString(1);
            int idCity = rs0.getInt(2);
            double vehicleCapacity = rs0.getDouble(3);
            int currentAddress = rs0.getInt(4);
            stmt1.setString(1, courierUsername);
            stmt1.setString(2, licencePlate);
            stmt1.setInt(3, currentAddress);
            stmt1.setDouble(4, 0);
            stmt1.executeUpdate();
            
            stmt2.setString(1, licencePlate);
            stmt2.executeUpdate();
            
            setCourierStatus(courierUsername, 1);
            //=======================================================================
            System.out.println("REACHED");
            // Dohvati sve pakete iz grada, sortirane rastuce po vremenu prihvatanja ponude
            stmt3.setInt(1, idCity);
            stmt3.setInt(2, 1);
            ResultSet rs3 = stmt3.executeQuery();
            boolean pickedUp = false;
            
            // Stavi sve pakete koje je moguce pokupiti u listu za kupljenje
            double load = 0;
            int nextAddress = 0;
            while(rs3.next()) {
                pickedUp = true;
                int idPackage = rs3.getInt(1);
                double weight = rs3.getDouble(2);
                int addressFrom = rs3.getInt(3);
                if (nextAddress == 0)
                    nextAddress = addressFrom;
                if (vehicleCapacity >= weight + load) {
                    stmt4.setInt(1, idPackage);
                    stmt4.setInt(2, addressFrom);
                    stmt4.setString(3, courierUsername);
                    stmt4.executeUpdate();
                    System.out.println("TO_COLLECT " + addressFrom);
                    load += weight;
                }
            }
            
            // Ako ima mesta idemo u magacin
            if (load < vehicleCapacity) {
                boolean toCollect = false;
                System.out.println("IDEMO U MAGACIN");
                stmt5.setInt(1, idCity);
                ResultSet rs5 = stmt5.executeQuery();
                while(rs5.next() && load < vehicleCapacity) {
                    int idPackage = rs5.getInt(1);
                    double weight = rs5.getDouble(2);
                    int stockroomAddress = rs5.getInt(3);
                    stmt4.setInt(1, idPackage);
                    stmt4.setInt(2, stockroomAddress);
                    stmt4.setString(3, courierUsername);
                    stmt4.executeUpdate();
                    System.out.println("DODATO");
                    toCollect = true;
                    load += weight;
                }
                if (pickedUp == false && toCollect == true)
                    nextAddress = getCourierStockroomAddress(courierUsername);
            }
            
            if (nextAddress == 0)
                return false;
            
            System.out.println("NEXT ADDRESS: " + nextAddress);
            calculateTotalDistance(courierUsername, getCourierStockroomAddress(courierUsername), nextAddress);
            setCourierAddress(courierUsername, nextAddress);
            
            if (pickedUp)
                System.out.println("TRUE");
            else 
                System.out.println("FALSE");
            return pickedUp;
        } catch (SQLException ex) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return false;
    }

    @Override
    public int nextStop(String courierUsername) {
        System.out.println("NEXT STOP");
        String query0 = "SELECT P.Id, P.Weight FROM Stored S INNER JOIN Stockroom ST "
                + "ON S.IdStockroom = ST.Id INNER JOIN Package P "
                + "ON P.Id = S.IdPackage "
                + "WHERE ST.IdAddress = ? ";
        String query1 = "SELECT P.Id, P.Weight FROM ToDeliver TD INNER JOIN Package P "
                + "ON TD.IdPackage = P.Id  "
                + "WHERE TD.Username = ? AND TD.IdAddress = ? ";
        String query2 = "SELECT * FROM ToDeliver WHERE Username = ? ";
        String query3 = "DELETE FROM ToDeliver "
                + "WHERE IdPackage = ? ";
        String query4 = "SELECT V.LicencePlate, V.Load, V.Capacity FROM Courier C INNER JOIN "
                + "Drives D ON D.Username = C.Username INNER JOIN "
                + "Vehicle V ON C.LicencePlate = V.LicencePlate "
                + "WHERE C.Username = ? ";
        String query5 = "UPDATE Vehicle SET Load = ? "
                + "WHERE Id = ? ";
        String query6 = "DELETE FROM Stored WHERE IdPackage = ? ";
        
        
        try (PreparedStatement stmt0 = con.prepareStatement(query0);
             PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);
             PreparedStatement stmt3 = con.prepareStatement(query3);
             PreparedStatement stmt4 = con.prepareStatement(query4);
             PreparedStatement stmt5 = con.prepareStatement(query5);
             PreparedStatement stmt6 = con.prepareStatement(query6);) {
            
            int currentCourierAddress = getCourierAddress(courierUsername);
            
            // Dohvati pakete koje treba pokupiti
            int stockroomAddress = getStockroomAddress(currentCourierAddress);
            
            int hometownStockroomAddress = getCourierStockroomAddress(courierUsername);
            
            double load = getVehicleLoad(courierUsername);
            double capacity = getVehicleCapacity(courierUsername);
            String licencePlate = getVehicleLicencePlate(courierUsername);
            boolean pickedUp = false;
            System.out.println("CURRENT ADDRESS: " + currentCourierAddress);
            System.out.println("STOCKROOM ADDRESS: " + stockroomAddress);
            if (currentCourierAddress != hometownStockroomAddress) {
                stmt1.setString(1, courierUsername);
                stmt1.setInt(2, currentCourierAddress);
                ResultSet rs1 = stmt1.executeQuery();
                while(rs1.next()) {
                    int idPackage = rs1.getInt(1);
                    double weight = rs1.getDouble(2); 
                    if (load+weight <= capacity) { 
                        setPackageStatus(idPackage, 2);
                        setPackageVehicle(idPackage, licencePlate, 0);
                        stmt3.setInt(1, idPackage);
                        stmt3.executeUpdate();
                        pickedUp = true;
                        load += weight;
                        updateVehicleLoad(courierUsername);
                        System.out.println("COLLECTED " + idPackage);
                        System.out.println("ADDRESS " + currentCourierAddress);
                    }
                } 

                stmt2.setString(1, courierUsername);
                ResultSet rs2 = stmt2.executeQuery();
                if (pickedUp) {
                    int nextAddress = -1;
                    if (rs2.next()) {
                        nextAddress = rs2.getInt("IdAddress");
                        System.out.println("PACKAGE ADDRESS");
                    } else {
                        nextAddress = getClosestAddress(courierUsername, currentCourierAddress);
                        System.out.println("STOCKROOM ADDRESS");
                        if (!isSameCity(currentCourierAddress, nextAddress)) {
                            planningPackagePickup(courierUsername, nextAddress);
                        }
                    }
                    System.out.println("NEXT ADDRESS " + nextAddress);
                    setCourierAddress(courierUsername, nextAddress);
                    updateVehicleLoad(courierUsername);
                    calculateTotalDistance(courierUsername, currentCourierAddress, nextAddress);
                    return -2;
                }
            } else {
                System.out.println("VISITING STOCKROOM ON ADDRESS: " + stockroomAddress);
                stmt0.setInt(1, stockroomAddress);
                ResultSet rs0 = stmt0.executeQuery();
                pickedUp = false;
                while(rs0.next()) {
                    int idPackage = rs0.getInt(1);
                    double weight = rs0.getDouble(2); 
                    
                    if (load+weight <= capacity) { 
                        setPackageStatus(idPackage, 2);
                        setPackageVehicle(idPackage, licencePlate, 0);
                        stmt3.setInt(1, idPackage);
                        stmt3.executeUpdate();
                        stmt6.setInt(1, idPackage);
                        stmt6.executeUpdate();
                        pickedUp = true;
                        load += weight;
                    }
                }
                
                if (pickedUp) {
                    int nextAddress = getClosestAddress(courierUsername, currentCourierAddress);
                    if (!isSameCity(currentCourierAddress, nextAddress)) {
                        planningPackagePickup(courierUsername, nextAddress);
                    }
                    setCourierAddress(courierUsername, nextAddress);
                    updateVehicleLoad(courierUsername);
                    calculateTotalDistance(courierUsername, currentCourierAddress, nextAddress);
                    System.out.println("I HAVE PICKED SOMETHING UP");
                    return -2;
                }
            }
            
            // DRUGA FAZA - DOSTAVA
            //int hometownStockroomAddress = getCourierStockroomAddress(courierUsername);
            System.out.println("HOMETOWN STOCKROOM ADDRESS: " + hometownStockroomAddress);
            
            if (currentCourierAddress != hometownStockroomAddress) {
                // Isporuka svih paketa za ovu adresu
                List<Integer> packages = getPackagesForAddress(currentCourierAddress);
                int ret = -1;
                System.out.println("PACKAGES SIZE: " + packages.size());
                for(Integer p: packages) {
                    setPackageStatus(p, 3);
                    setPackageVehicle(p, "", -1);
                    addPackageToDelivered(courierUsername, p);
                    ret = p;
                }
                System.out.println("RET: " + ret);
                updateVehicleLoad(courierUsername);
                // Skupljanje paketa sa trenutne adrese koje treba dostaviti u magacin
                boolean collected = collectPackagesFromThisAddress(courierUsername, currentCourierAddress);
                System.out.println("MARK 1");
                int nextAddress = getClosestAddress(courierUsername, currentCourierAddress);
                
                System.out.println("NEXT ADDRESS: " + nextAddress);
                if (nextAddress > -1) {
                    if (!isSameCity(currentCourierAddress, nextAddress)) {
                        planningPackagePickup(courierUsername, nextAddress);
                    }
                    calculateTotalDistance(courierUsername, getCourierAddress(courierUsername), nextAddress);
                    System.out.println("MARK 2");
                    setCourierAddress(courierUsername, nextAddress);
                }
                
                if (nextAddress == -1 && ret > -1)
                    return ret;
                System.out.println("MARK 3");
                if (ret == -1 && collected == true) {
                    System.out.println("ONLY COLLECT");
                    if (nextAddress == -1) {
                        setCourierAddress(courierUsername, hometownStockroomAddress);
                    }
                    return -2;
                }

                System.out.println("DELIEVERED: " + ret);
                System.out.println("ADDRESS: " + currentCourierAddress);
                if (ret == -1) {
                    calculateTotalDistance(courierUsername, getCourierAddress(courierUsername), hometownStockroomAddress);
                    calculateProfit(courierUsername);
                    leavePackagesInStockroom(courierUsername);
                    setCourierStatus(courierUsername, 0);
                } else {
                    calculateTotalDistance(courierUsername, getCourierAddress(courierUsername), nextAddress);
                    System.out.println("MARK 2");
                    setCourierAddress(courierUsername, nextAddress);
                }
                return ret;
            } else {
                calculateProfit(courierUsername);
                leavePackagesInStockroom(courierUsername);
                setCourierStatus(courierUsername, 0);
                System.out.println("DELIEVERY END");
                return -1;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("ITS OUTSIDE TRY CATCH");
        return -3;
    }

    @Override
    public List<Integer> getPackagesInVehicle(String courierUsername) {
        String query = "SELECT T.IdPackage FROM Courier C "
                + "INNER JOIN Drives D ON C.Username = D.Username "
                + "INNER JOIN Trunk T ON D.LicencePlate = T.LicencePlate "
                + "WHERE D.Username = ? ";

        System.out.println("PACKAGES IN VEHICLE");
        List<Integer> ret = new ArrayList<>();
        try (PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setString(1, courierUsername);
            ResultSet res = stmt.executeQuery();
            while (res.next()) {
                ret.add(res.getInt(1));
                System.out.println("PACKAGE ID: " + res.getInt(1));
            }
            return ret;
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return ret;
    }
    
    //========================================================================================================================
    
    private static void leavePackagesInStockroom(String courierUsername) {
        String query1 = "SELECT T.IdPackage FROM Trunk T INNER JOIN "
                + "Drives D ON T.LicencePlate = D.LicencePlate "
                + "WHERE D.Username = ? AND T.Type = 1";
        String query2 = "SELECT S.Id FROM Stockroom S INNER JOIN "
                + "Address A ON S.IdCity = A.IdCity INNER JOIN"
                + "[User] U ON U.IdAddress = A.Id "
                + "WHERE U.Username = ? ";
        String query3 = "INSERT INTO Stored(IdPackage, IdStockroom) "
                + "VALUES(?,?) ";
        String query4 = "DELETE FROM Drives WHERE Username = ?";
        String query5 = "INSERT INTO Parked(LicencePlate, IdStockroom) VALUES(?,?)";
        String query6 = "SELECT * FROM Drove WHERE Username = ? AND LicencePlate = ?";
        String query7 = "INSERT INTO Drove(LicencePlate, Username) VALUES(?,?)";
        
        
        
        System.out.println("LEAVE PACKAGES IN STOCKROOM " + courierUsername);
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);
             PreparedStatement stmt3 = con.prepareStatement(query3);
             PreparedStatement stmt4 = con.prepareStatement(query4);
             PreparedStatement stmt5 = con.prepareStatement(query5);
             PreparedStatement stmt6 = con.prepareStatement(query6);
             PreparedStatement stmt7 = con.prepareStatement(query7);) {
            
            stmt1.setString(1, courierUsername);
            ResultSet rs1 = stmt1.executeQuery();
            stmt2.setString(1, courierUsername);
            ResultSet rs2 = stmt2.executeQuery();
            rs2.next();
            int idStockroom = rs2.getInt(1);
            while(rs1.next()) {
                int idPackage = rs1.getInt(1);
                setPackageVehicle(idPackage, "", 0);
                stmt3.setInt(1, idPackage);
                stmt3.setInt(2, idStockroom);
                stmt3.executeUpdate();
                //setPackageStatus(idPackage, 1);
            }
            updateVehicleLoad(courierUsername);
            
            String licencePlate = getVehicleLicencePlate(courierUsername);

            stmt4.setString(1, courierUsername);
            stmt4.executeUpdate();
            
            stmt5.setString(1, licencePlate);
            stmt5.setInt(2, idStockroom);
            stmt5.executeUpdate();
            
            stmt6.setString(1, courierUsername);
            stmt6.setString(2, licencePlate);
            ResultSet rs6 = stmt6.executeQuery();
            if (rs6.next() == false) {
                stmt7.setString(1, licencePlate);
                stmt7.setString(2, courierUsername);
                stmt7.executeUpdate();
            }
        } catch (SQLException ex) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private static void calculateProfit(String courierUsername) {
        String query1 = "SELECT IdPackage FROM Delivered "
                + "WHERE Username = ? ";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);) {
            stmt1.setString(1, courierUsername);
            ResultSet rs1 = stmt1.executeQuery();
            BigDecimal currentProfit = getCourierProfit(courierUsername);
            BigDecimal totalProfit = new BigDecimal(BigInteger.ZERO);
            int numDelivered = 0;
            while (rs1.next()) {
                int packageId = rs1.getInt(1);
                BigDecimal packagePrice = getPackagePrice(packageId);
                System.out.println("PACKAGE PRICE: " + packagePrice);
                totalProfit = totalProfit.add(packagePrice);
                ++numDelivered;
            }
            setCourierDeliveredPackages(courierUsername, numDelivered);
            double courierFuelEff = getCourierFuelConsumption(courierUsername).doubleValue();
            double fuelPrice = getCourierFuelPrice(courierUsername).doubleValue();
            System.out.println("FUEL EFF: " + courierFuelEff);
            System.out.println("FUEL PRICE: " + fuelPrice);
            System.out.println("TOTAL TRAVEL DISTANCE: " + getTotalTravelDistance(courierUsername));
            
            BigDecimal travelCost = new BigDecimal(getTotalTravelDistance(courierUsername)).multiply(new BigDecimal(courierFuelEff)).multiply(new BigDecimal(fuelPrice));
            System.out.println("TRAVEL COST: " + travelCost);
            System.out.println("TOTAL PROFIT: " + totalProfit);
            
            totalProfit = totalProfit.subtract(travelCost);
            currentProfit = currentProfit.add(totalProfit);
            System.out.println("COURIER PROFIT: " + currentProfit);
            setCourierProfit(courierUsername, currentProfit);
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }
    }
    
    private static double getTotalTravelDistance(String courierUsername) {
        String query = "SELECT TravelDistance FROM Drives "
                + "WHERE Username = ? ";
        
        try (PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setString(1, courierUsername);
            ResultSet res = stmt.executeQuery();
            if (res.next())
                return res.getDouble(1);
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return 0;
    }
    
    private static void calculateTotalDistance(String courierUsername, int currentAddress, int nextAddress) {
        String query1 = "SELECT xCoord, yCoord FROM Address WHERE Id = ? ";
        String query2 = "UPDATE Drives SET TravelDistance = ? "
                + "WHERE Username = ? ";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);) {
            stmt1.setInt(1, currentAddress);
            ResultSet rs1 = stmt1.executeQuery();
            Coordinates coordA = null;
            if (rs1.next()) {
                int x_coord = rs1.getInt(1);
                int y_coord = rs1.getInt(2);
                System.out.println("X: " + x_coord + ", Y: " + y_coord);
                coordA = new Coordinates(x_coord, y_coord, currentAddress);
            }
            
            stmt1.setInt(1, nextAddress);
            rs1 = stmt1.executeQuery();
            Coordinates coordB = null;
            if (rs1.next()) {
                int x_coord = rs1.getInt(1);
                int y_coord = rs1.getInt(2);
                System.out.println("X: " + x_coord + ", Y: " + y_coord);
                coordB = new Coordinates(x_coord, y_coord, currentAddress);
            }
            
            double dist = euclideanDistance(coordA, coordB);
            
            double totalDistance = getTotalTravelDistance(courierUsername);
            
            totalDistance += dist;
            stmt2.setDouble(1, totalDistance);
            stmt2.setString(2, courierUsername);
            stmt2.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private static int getCourierStockroomAddress(String courierUsername) {
        String query = "SELECT S.IdAddress FROM Courier C INNER JOIN "
                + "[User] U ON C.Username = U.Username INNER JOIN "
                + "Address A ON U.IdAddress = A.Id INNER JOIN "
                + "City CT ON CT.Id = A.IdCity INNER JOIN "
                + "Stockroom S ON S.IdCity = CT.Id "
                + "WHERE C.Username = ? ";
        
        try (PreparedStatement stmt = con.prepareStatement(query);) {
            List<Integer> ret = new ArrayList<>();
            stmt.setString(1, courierUsername);
            ResultSet res = stmt.executeQuery();
            if (res.next())
                return res.getInt(1);
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return -1;
    }
    
    private static boolean collectPackagesFromThisAddress(String courierUsername, int address) {
        String query1 = "SELECT LicencePlate FROM Drives WHERE Username = ? ";
        String query2 = "SELECT P.Id, P.Weight FROM Stored S INNER JOIN "
                + "Package P ON S.IdPackage = P.Id INNER JOIN "
                + "ToStock TS ON TS.IdPackage = P.Id INNER JOIN "
                + "Stockroom ST ON ST.Id = S.IdStockroom "
                + "WHERE ST.IdAddress = ? ";
        String query3 = "SELECT P.Id, P.Weight FROM Package P INNER JOIN "
                + "ToStock TS ON TS.IdPackage = P.Id "
                + "WHERE P.AddressFrom = ? ";
        String query4 = "DELETE FROM Stored WHERE IdPackage = ? ";
        String query5 = "DELETE FROM ToStock WHERE IdPackage = ? ";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);
             PreparedStatement stmt3 = con.prepareStatement(query3);
             PreparedStatement stmt4 = con.prepareStatement(query4);
             PreparedStatement stmt5 = con.prepareStatement(query5);) {
            String licencePlate = "";
            stmt1.setString(1, courierUsername);
            ResultSet rs1 = stmt1.executeQuery();
            if (rs1.next())
                licencePlate = rs1.getString(1);
            
            boolean collected = false;
            double load = getVehicleLoad(courierUsername);
            double capacity = getVehicleCapacity(courierUsername);
            if (isStockroom(address)) {
                stmt2.setInt(1, address);
                ResultSet rs2 = stmt2.executeQuery();
                while(rs2.next()) {
                    int idPackage = rs2.getInt(1);
                    double weight = rs2.getDouble(2);
                    if (load + weight <= capacity) {
                        setPackageVehicle(idPackage, licencePlate, 1);
                        setPackageStatus(idPackage, 2);
                        System.out.println("COLLECTED PACKAGE ID: " + idPackage);
                        collected = true;
                        load+=weight;
                    }
                    stmt4.setInt(1, idPackage);
                    stmt4.executeUpdate();
                    
                    stmt5.setInt(1, idPackage);
                    stmt5.executeUpdate();
                }
            } else {
                stmt3.setInt(1, address);
                ResultSet rs3 = stmt3.executeQuery();
                while(rs3.next()) {
                    int idPackage = rs3.getInt(1);
                    double weight = rs3.getDouble(2);
                    if (load + weight <= capacity) {
                        setPackageVehicle(idPackage, licencePlate, 1);
                        setPackageStatus(idPackage, 2);
                        System.out.println("COLLECTED PACKAGE ID: " + idPackage);
                        collected = true;
                        load+=weight;
                    }
                    stmt4.setInt(1, idPackage);
                    stmt4.executeUpdate();
                    
                    stmt5.setInt(1, idPackage);
                    stmt5.executeUpdate();
                }
            }
            
            updateVehicleLoad(courierUsername); 
            return collected;
        } catch (SQLException ex) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
    
    private static boolean isStockroom(int address) {
        String query = "SELECT Id FROM Stockroom WHERE IdAddress = ? ";
        
        try (PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setInt(1, address);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException ex) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    private static void planningPackagePickup(String courierUsername, int address)  {
        String query1 = "SELECT IdCity FROM Address WHERE Id = ? ";
        String query2 = "SELECT P.Weight FROM Package P INNER JOIN "
                + "Address A ON P.AddressTo = A.Id "
                + "WHERE A.IdCity = ? AND P.Status = ? ";
        String query3 = "SELECT P.Id, P.Weight FROM Package P INNER JOIN "
                + "Address A ON P.AddressFrom = A.Id INNER JOIN "
                + "City C ON C.Id = A.IdCity INNER JOIN "
                + "Offer O ON O.IdPackage = P.Id INNER JOIN "
                + "AcceptedOffer AO ON AO.IdOffer = O.Id "
                + "WHERE C.Id = ? AND P.Status = ? "
                + "ORDER BY AO.AcceptedTime ";
        String query4 = "INSERT INTO ToStock(IdPackage, Username) "
                + "VALUES(?,?) ";
        String query5 = "SELECT P.Id, P.Weight FROM Package P INNER JOIN "
                + "Stored S ON P.Id = S.IdPackage INNER JOIN "
                + "Stockroom ST ON S.IdStockroom = ST.Id INNER JOIN "
                + "Offer O ON O.IdPackage = P.Id INNER JOIN "
                + "AcceptedOffer AO ON AO.IdOffer = O.Id "
                + "WHERE ST.IdCity = ?";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);
             PreparedStatement stmt3 = con.prepareStatement(query3);
             PreparedStatement stmt4 = con.prepareStatement(query4);
             PreparedStatement stmt5 = con.prepareStatement(query5);) {
            
            stmt1.setInt(1, address);
            ResultSet rs1 = stmt1.executeQuery();
            rs1.next();
            int cityId = rs1.getInt(1);
            
            stmt2.setInt(1, cityId);
            stmt2.setInt(2, 2);
            ResultSet rs2 = stmt2.executeQuery();
            double capacity = getVehicleCapacity(courierUsername);
            double load = getVehicleLoad(courierUsername);
            while(rs2.next()) {
                load -= rs2.getDouble(1);
            }
            
            stmt3.setInt(1, cityId);
            stmt3.setInt(2, 1);
            ResultSet rs3 = stmt3.executeQuery();
            while(rs3.next()) {
                int idPackage = rs3.getInt(1);
                double weight = rs3.getDouble(2);
                if (load < capacity) {
                    System.out.println("TO STOCK: " + idPackage);
                    stmt4.setInt(1, idPackage);
                    stmt4.setString(2, courierUsername);
                    stmt4.executeUpdate();
                    load+=weight;
                } else {
                    break;
                }
            }
            
            if (load < capacity) {
                stmt5.setInt(1, cityId);
                ResultSet rs5 = stmt5.executeQuery();
                while(rs5.next() && load < capacity) {
                    stmt4.setInt(1, rs5.getInt(1));
                    stmt4.setString(2, courierUsername);
                    stmt4.executeUpdate();
                    System.out.println("TO STOCK: " + rs5.getInt(1));
                    load+=rs5.getDouble(2);
                }
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }
    }
    
    private static double getVehicleLoad(String courierUsername) {
        String query1 = "SELECT V.Load FROM Vehicle V INNER JOIN "
                + "Drives D ON D.LicencePlate = V.LicencePlate "
                + "WHERE D.Username = ? ";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);) {
            stmt1.setString(1, courierUsername);
            ResultSet rs = stmt1.executeQuery();
            if (rs.next())
                return rs.getDouble(1);
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }
        return 0;
    }
    
    private static String getVehicleLicencePlate(String courierUsername) {
        String query1 = "SELECT LicencePlate FROM Drives WHERE Username = ? ";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);) {
            stmt1.setString(1, courierUsername);
            ResultSet rs = stmt1.executeQuery();
            if (rs.next())
                return rs.getString(1);
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }
        return "";
    }
    
    private static double getVehicleCapacity(String courierUsername) {
        String query1 = "SELECT V.Capacity FROM Vehicle V INNER JOIN "
                + "Drives D ON D.LicencePlate = V.LicencePlate "
                + "WHERE D.Username = ? ";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);) {
            stmt1.setString(1, courierUsername);
            ResultSet rs = stmt1.executeQuery();
            if (rs.next())
                return rs.getDouble(1);
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }
        return 0;
    }
    
    private static void updateVehicleLoad(String courierUsername) {
        String query1 = "SELECT P.Weight, T.LicencePlate FROM Package P INNER JOIN "
                + "Trunk T ON P.Id = T.IdPackage INNER JOIN "
                + "Drives D ON T.LicencePlate = D.LicencePlate "
                + "WHERE D.Username = ? ";
        String query2 = "UPDATE Vehicle SET Load = ? WHERE LicencePlate = ? ";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);) {
            stmt1.setString(1, courierUsername);
            ResultSet rs = stmt1.executeQuery();
            if (rs.next()) {
                String licencePlate = rs.getString(2);
                double load = rs.getDouble(1);
                while(rs.next()) {
                    load += rs.getDouble(1);
                }
                stmt2.setDouble(1, load);
                stmt2.setString(2, licencePlate);
                stmt2.executeUpdate();
            } else {
                String licencePlate = getVehicleLicencePlate(courierUsername);
                
                stmt2.setDouble(1, 0);
                stmt2.setString(2, licencePlate);
                stmt2.executeUpdate();
            }
            
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }
    }
    
    private static void addPackageToDelivered(String courierUsername, int packageId) {
        String query = "INSERT INTO Delivered(IdPackage, Username) "
                + "VALUES(?,?) ";
        
        try (PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setInt(1, packageId);
            stmt.setString(2, courierUsername);
            stmt.executeUpdate();
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }
    }
    
    private static List<Integer> getPackagesForAddress(int address) {
        String query = "SELECT Id FROM Package P INNER JOIN Trunk T "
                + "ON P.Id = T.IdPackage "
                + "WHERE P.AddressTo = ? AND P.Status = ? AND T.Type = 0";

        List<Integer> ret = new ArrayList<>();
        try (PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setInt(1, address);
            stmt.setInt(2, 2);
            ResultSet res = stmt.executeQuery();
            while (res.next()) {
                ret.add(res.getInt(1));
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return ret;
    }
    
    private static List<Integer> getPackagesToPickup(String courierUsername) {
        String query = "SELECT * FROM ToStock WHERE Username = ? ";
        
        List<Integer> list = new ArrayList<>();
        try (PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setString(1, courierUsername);
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()) {
                list.add(rs.getInt("IdPackage"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
    
    private static List<Integer> getPackagesToDeliver(String courierUsername) {
        String query = "SELECT p.Id FROM Drives d "
                + "INNER JOIN Trunk t ON d.LicencePlate = t.LicencePlate "
                + "INNER JOIN Package p ON p.Id = t.IdPackage "
                + "WHERE d.Username = ? AND p.Status = ? AND t.Type = 0";

        List<Integer> ret = new ArrayList<>();
        try (PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setString(1, courierUsername);
            stmt.setInt(2, 2);
            ResultSet res = stmt.executeQuery();
            while (res.next()) {
                ret.add(res.getInt(1));
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return ret;
    }
    
    private static int getClosestAddress(String courierUsername, int currentAddress) {
        String query = "SELECT xCoord, yCoord FROM Address "
                + "WHERE Id = ? ";
        
        try (PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setInt(1, currentAddress);
            ResultSet rs = stmt.executeQuery();
            rs.next();
            int x_coord = rs.getInt(1);
            int y_coord = rs.getInt(2);
            Coordinates origin_coord = new Coordinates(x_coord, y_coord, currentAddress);
            List<Integer> stockList = getPackagesToPickup(courierUsername);
            double minDistance = Double.MAX_VALUE;
            int selectedPackage = -1;
            int selectedPackageStored = -1;
            int selectedPackageNonStored = -1;
            
            for(int i=0;i<stockList.size();i++) {
                int idPackage = stockList.get(i);
                
                if (isStored(idPackage)) {
                    System.out.println("StoredPackage: " + idPackage);
                    int storedPackageAddress = getStoredPackageAddress(idPackage);
                    System.out.println("StoredPackageAddress: " + storedPackageAddress);
                    Coordinates coord = getAddressCoordinates(storedPackageAddress);
                    if (euclideanDistance(origin_coord, coord) < minDistance) {
                        minDistance = euclideanDistance(origin_coord, coord);
                        selectedPackageStored = idPackage;
                        selectedPackage = idPackage;
                    }
                } 
            }
            
            minDistance = Double.MAX_VALUE;
            for(int i=0;i<stockList.size();i++) {
                int idPackage = stockList.get(i);
                
                if (!isStored(idPackage)) {
                    System.out.println("NonStoredPackage: " + idPackage);
                    Coordinates coord = getPackageFromCoordinates(idPackage);
                    System.out.println("NonStoredPackageAddress: " + coord.getAddress());
                    if (euclideanDistance(origin_coord, coord) < minDistance) {
                        minDistance = euclideanDistance(origin_coord, coord);
                        selectedPackageNonStored = idPackage;
                        selectedPackage = idPackage;
                    }
                }
            }
            
            if (selectedPackageStored > -1 && selectedPackageNonStored > -1){
                int storedPackageAddress = getStoredPackageAddress(selectedPackageStored);
                int nonStoredPackageAddress = getPackageFromCoordinates(selectedPackageNonStored).getAddress();
                System.out.println("STOREDPackageAddress: " + storedPackageAddress);
                System.out.println("NONSTOREDPackageAddress: " + nonStoredPackageAddress);
                if (isSameCity(storedPackageAddress, nonStoredPackageAddress)) {
                    System.out.println("SAME CITY PACKAGES PICKUP");
                    selectedPackage = selectedPackageNonStored;
                }
            }
            System.out.println("SELECTED PACKAGE: " + selectedPackage);
            int address1 = -1;
            if (selectedPackage > -1) {
                
                if (isStored(selectedPackage)){
                    System.out.println("SELPAK 1");
                    address1 = getStoredPackageAddress(selectedPackage);
                } else {
                    System.out.println("SELPAK 2");
                    address1 = getPackageFromCoordinates(selectedPackage).getAddress();
                }
            }
            
            selectedPackage = -1;
            List<Integer> deliverList = getPackagesToDeliver(courierUsername);
            for(int i=0;i<deliverList.size();i++) {
                int idPackage = deliverList.get(i);
                Coordinates coord = getPackageToCoordinates(idPackage);
                if (euclideanDistance(origin_coord, coord) < minDistance) {
                    minDistance = euclideanDistance(origin_coord, coord);
                    selectedPackage = idPackage;
                }
            }
            
            int address2 = -1;
            if (selectedPackage > -1) {
                address2 = getPackageToCoordinates(selectedPackage).getAddress();
            }
            
            if (address1 == -1 && address2 == -1)
                return -1;
            
            if (address1 == -1 && address2 > -1)
                return address2;
            
            if (address1 > -1 && address2 == -1)
                return address1;
            
            if (isSameCity(address1, address2))
                return address2;
            else
                return address1;
            
        } catch (SQLException ex) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return -1;
    }
    
    private static boolean isStored(int idPackage) {
        String query = "SELECT * FROM Stored WHERE IdPackage = ?";
        
        try (PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setInt(1, idPackage);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException ex) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return false;
    }
    
    private static int getStoredPackageAddress(int idPackage) {
        String query = "SELECT ST.IdAddress FROM Stored S INNER JOIN Stockroom ST "
                + "ON S.IdStockroom = ST.Id "
                + "WHERE S.IdPackage = ?";
        
        try (PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setInt(1, idPackage);
            ResultSet rs = stmt.executeQuery();
            rs.next();
            return rs.getInt(1);
        } catch (SQLException ex) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return -1;
    }
    
    private static Coordinates getAddressCoordinates(int idAddress) {
        String query = "SELECT xCoord, yCoord FROM Address "
                + "WHERE Id = ?";
        
        try (PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setInt(1, idAddress);
            ResultSet rs = stmt.executeQuery();
            rs.next();
            return new Coordinates(rs.getInt(1), rs.getInt(2), idAddress);
        } catch (SQLException ex) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return null;
    }
    
    private static int getStockroomAddress(int currentAddress) {
        String query1 = "SELECT IdCity FROM Address WHERE Id = ?";
        String query2 = "SELECT IdAddress FROM Stockroom "
                + "WHERE IdCity = ? ";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);) {
            stmt1.setInt(1, currentAddress);
            ResultSet rs1 = stmt1.executeQuery();
            rs1.next();
            int idCity = rs1.getInt(1);
            
            stmt2.setInt(1, idCity);
            ResultSet rs2 = stmt2.executeQuery();
            if (rs2.next())
                return rs2.getInt(1);
        } catch (SQLException ex) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
        return -1;
    }
    
    private static int getCourierAddress(String courierUsername) {
        String query = "SELECT IdAddress FROM Drives "
                + "WHERE Username = ? ";
        
        try (PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setString(1, courierUsername);
            ResultSet rs = stmt.executeQuery();
            if (rs.next())
                return rs.getInt(1);
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return -1;
    }
    
    private static int getCourierVehicle(String courierUsername) {
        String query = "SELECT LicencePlate FROM Drives "
                + "WHERE Username = ? ";
        
        try (PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setString(1, courierUsername);
            ResultSet rs = stmt.executeQuery();
            if (rs.next())
                return rs.getInt(1);
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return -1;
    }
    
    private static boolean isSameCity(int address1, int address2) {
        String query = "SELECT IdCity FROM Address "
                + "WHERE Id = ? ";
        
        try (PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setInt(1, address1);
            ResultSet rs = stmt.executeQuery();
            rs.next();
            int city1 = rs.getInt(1);
            
            stmt.setInt(1, address2);
            rs = stmt.executeQuery();
            rs.next();
            int city2 = rs.getInt(1);
            
            return city1 == city2;
        } catch (SQLException ex) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    private static Double euclideanDistance(Coordinates a, Coordinates b) {
        return Math.sqrt(Math.pow(a.getX() - b.getX(), 2) + Math.pow(a.getY() - b.getY(), 2));
    }

    private static boolean setPackageStatus(Integer packageId, Integer status) {
        String query = "UPDATE Package SET Status = ? WHERE Id = ?";
        
        try (PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setInt(1, status);
            stmt.setInt(2, packageId);
            if (stmt.executeUpdate() == 1) {
                return true;
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return false;
    }
    
    private static boolean setPackageVehicle(Integer packageId, String licencePlate, int type) {
        String query1 = "INSERT INTO Trunk(IdPackage, LicencePlate, Type) "
                + "VALUES(?,?,?) ";
        String query2 = "DELETE Trunk WHERE IdPackage = ?";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);) {
            if(!"".equals(licencePlate)) {
                stmt1.setInt(1, packageId);
                stmt1.setString(2, licencePlate);
                stmt1.setInt(3, type);
                stmt1.executeUpdate();
            } else {
                stmt2.setInt(1, packageId);
                stmt2.executeUpdate();
            }
            return true;
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return false;
    }

    private static Coordinates getPackageFromCoordinates(int packageId) {
        String query = "SELECT a.xCoord, a.yCoord, a.Id FROM Package p INNER JOIN Address a ON p.AddressFrom = a.Id and p.Id = ?";

        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, packageId);
            try (ResultSet res = stmt.executeQuery()) {
                if (res.next()) {
                    return new Coordinates(res.getInt(1), res.getInt(2), res.getInt(3));
                }
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return null;
    }

    private static Coordinates getPackageToCoordinates(int packageId) {
        String query = "SELECT a.xCoord, a.yCoord, a.Id FROM Package p INNER JOIN Address a ON p.AddressTo = a.Id AND p.Id = ?";
        
        Coordinates ret = null;
        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, packageId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    ret = new Coordinates(rs.getInt(1), rs.getInt(2), rs.getInt(3));
                }
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return ret;
    }

    private static BigDecimal getPackagePrice(int packageId) {
        String query = "SELECT Price FROM Package WHERE Id = ?";
        
        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, packageId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (!rs.next() || rs.wasNull()) {
                    return null;
                }
                return rs.getBigDecimal("Price");

            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return null;
    }
    
    private static BigDecimal getCourierProfit(String username) {
        String query = "SELECT Profit FROM Courier WHERE Username = ?";

        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setString(1, username);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getBigDecimal("Profit");
                }
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return null;
    }

    private static BigDecimal getCourierFuelConsumption(String username) {
        String query = "SELECT v.FuelConsumption FROM Vehicle v "
                     + "INNER JOIN Drives d ON d.LicencePlate = v.LicencePlate "
                     + "WHERE d.Username = ?";

        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setString(1, username);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getBigDecimal(1);
                }
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return null;
    }

    private static BigDecimal getCourierFuelPrice(String username) {
        String query = "SELECT f.Price FROM Vehicle v "
                     + "INNER JOIN Drives d ON d.LicencePlate = v.LicencePlate AND d.Username = ? "
                     + "INNER JOIN Fuel f ON f.FuelType = v.FuelType";

        try (PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setString(1, username);
            ResultSet res = stmt.executeQuery();
            if (res.next()) {
                return res.getBigDecimal(1);
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return null;
    }
  
    public static Integer getCourierStatus(String username) {
        String query = "SELECT Status FROM Courier WHERE Username = ?";
        
        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setString(1, username);
            ResultSet res = stmt.executeQuery();
            if (res.next()) {
                return res.getInt("Status");
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return 0;
    }

    public static boolean setCourierStatus(String username, Integer status) {
        String query = "UPDATE Courier SET Status = ? WHERE Username = ?";

        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, status);
            stmt.setString(2, username);
            if (stmt.executeUpdate() == 1) {
                return true;
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return false;
    }

    public static boolean setCourierProfit(String username, BigDecimal profit) {
        String query = "UPDATE Courier SET Profit = ? WHERE Username = ?";
        
        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setDouble(1, profit.doubleValue());
            stmt.setString(2, username);
            if (stmt.executeUpdate() == 1) {
                return true;
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return false;
    }
    
    public static boolean setCourierAddress(String username, int address) {
        String query = "UPDATE Drives SET IdAddress = ? WHERE Username = ?";
        
        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, address);
            stmt.setString(2, username);
            if (stmt.executeUpdate() == 1) {
                return true;
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_DriveOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return false;
    }
    
    public static Integer getCourierDeliveredPackages(String username) {
        String query = "SELECT NumDeliveries FROM Courier WHERE Username = ?";
        
        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setString(1, username);
            ResultSet res = stmt.executeQuery();
            if (res.next()) {
                return res.getInt("NumDeliveries");
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }

        return null;
    }
    
    public static boolean setCourierDeliveredPackages(String username, int deliveredPackages) {
        String query = "UPDATE Courier SET NumDeliveries = ? WHERE Username = ?";

        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, deliveredPackages);
            stmt.setString(2, username);
            if (stmt.executeUpdate() == 1) {
                return true;
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }

        return false;
    }
}
