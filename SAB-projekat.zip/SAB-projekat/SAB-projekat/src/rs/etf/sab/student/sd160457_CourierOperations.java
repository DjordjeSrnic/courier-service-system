/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.*;

/**
 *
 * @author Djordje
 */
public class sd160457_CourierOperations implements CourierOperations{

    private Connection con;
    
    public sd160457_CourierOperations() {
        this.con = DB.getInstance().getConnection();
    }
    
    @Override
    public boolean insertCourier(String courierUserName, String licencePlateNumber) {
        String query1 = "SELECT * FROM Courier WHERE Username = ?";
        String query2 = "SELECT * FROM Courier WHERE LicenceNumber = ?";
        String query3 = "SELECT * FROM [User] WHERE Username = ?";
        String query4 = "INSERT INTO Courier(Username, LicenceNumber, NumDeliveries, Profit, Status) VALUES(?,?,?,?,?)";
        

        try (PreparedStatement stmt1=con.prepareStatement(query1);
             PreparedStatement stmt2=con.prepareStatement(query2);
             PreparedStatement stmt3=con.prepareStatement(query3);   
             PreparedStatement stmt4=con.prepareStatement(query4);) {
              
            stmt1.setString(1, courierUserName);
            ResultSet res1 = stmt1.executeQuery();
            if (res1.next() == true) {
                return false;
            }

            stmt2.setString(1, licencePlateNumber);
            ResultSet res2 = stmt2.executeQuery();
            if (res2.next() == true) {
                return false;
            }

            stmt3.setString(1, courierUserName);
            ResultSet res3 = stmt3.executeQuery();
            if (res3.next() == false) {
                return false;
            }

            stmt4.setString(1, courierUserName);
            stmt4.setString(2, licencePlateNumber);
            stmt4.setBigDecimal(3, BigDecimal.ZERO);
            stmt4.setInt(4, 0);
            stmt4.setInt(5, 0);
            int ret=stmt4.executeUpdate();
            if(ret==1) 
                return true;
            else 
                return false;
        } catch (SQLException e) {
            Logger.getLogger(sd160457_CourierOperations.class.getName()).log(Level.SEVERE, null, e);
            return false;
        }
    }

    @Override
    public boolean deleteCourier(String courierUserName) {
        String query1 = "SELECT * FROM Drives WHERE Username = ?";
        String query2 = "DELETE Courier WHERE Username = ?";
        
        try(PreparedStatement stmt1 = con.prepareStatement(query1);
            PreparedStatement stmt2 = con.prepareStatement(query2);) {
            
            stmt1.setString(1, courierUserName);
            ResultSet rs1 = stmt1.executeQuery();
            if (rs1.next())
                return false;
            
            stmt2.setString(1, courierUserName);
            int ret = stmt2.executeUpdate();
            if (ret == 0) 
                return false;
            else 
                return true;
        } catch (SQLException e) {
            Logger.getLogger(sd160457_CourierOperations.class.getName()).log(Level.SEVERE, null, e);
        }
        return false;
    }

    @Override
    public List<String> getCouriersWithStatus(int statusOfCourier) {
        String query1 = "SELECT * FROM Courier WHERE Status=?";
        
        List<String> lista=new ArrayList<>();
        try (PreparedStatement stmt1 = con.prepareStatement(query1);) {
            
            stmt1.setInt(1, statusOfCourier);
            ResultSet res1=stmt1.executeQuery();
            while(res1.next()){
                lista.add(res1.getString("Username"));
            }
            
        } catch (SQLException e) {
            Logger.getLogger(sd160457_CourierOperations.class.getName()).log(Level.SEVERE, null, e);
        }
        System.out.println("COURIERS WITH STATUS: " + lista.size());
        return lista;
    }

    @Override
    public List<String> getAllCouriers() {
        String query1 = "SELECT * FROM Courier";
        
        List<String> lista=new ArrayList<>();
        try (PreparedStatement stmt1 = con.prepareStatement(query1);) {
            ResultSet res1=stmt1.executeQuery();
            while(res1.next()){
                lista.add(res1.getString("Username"));
            }
            
        } catch (SQLException e) {
            Logger.getLogger(sd160457_CourierOperations.class.getName()).log(Level.SEVERE, null, e);
        }
        return lista;
    }

    @Override
    public BigDecimal getAverageCourierProfit(int numberOfDeliveries) {
        String query1="SELECT Profit FROM Courier WHERE NumDeliveries = ?";
        String query2="SELECT Profit FROM Courier";
        
        System.out.println("AVG PROFIT " + numberOfDeliveries);
        try (PreparedStatement ps1=con.prepareStatement(query1);
             PreparedStatement ps2=con.prepareStatement(query2);) {
            if (numberOfDeliveries != -1) {
                ps1.setInt(1, numberOfDeliveries);
                ResultSet res1=ps1.executeQuery();
                int broj=0;
                BigDecimal profit=new BigDecimal(BigInteger.ZERO);
                System.out.println("Profit"+ profit);
                
                while(res1.next()){
                    broj++;
                    profit =profit.add(res1.getBigDecimal(1));
                }
                
                profit = profit.divide(new BigDecimal(broj));
                System.out.println("AvgProfit"+ profit);
                return profit;
            } else {
                ResultSet res2=ps2.executeQuery();
                int broj=0;
                double profit=new BigDecimal(BigInteger.ZERO).doubleValue();
                System.out.println("Profit"+ profit);
                while(res2.next()){
                    broj++;
                    profit+=res2.getBigDecimal(1).doubleValue();
                }
                System.out.println("Profit"+ profit);
                BigDecimal ret=new BigDecimal(profit);
                return ret;
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_CourierOperations.class.getName()).log(Level.SEVERE, null, e);
        }
        
        return new BigDecimal(BigInteger.ZERO);
    }
    
}
