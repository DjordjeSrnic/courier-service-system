/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.*;
/**
 *
 * @author Djordje
 */
public class sd160457_AddressOperations implements AddressOperations {

    private Connection con;
    
    public sd160457_AddressOperations() {
        this.con = DB.getInstance().getConnection();
    }
    
    @Override
    public int insertAddress(String name, int number, int cityId, int xCord, int yCord) {
        
        String query1 = "SELECT * FROM Address WHERE Number=? AND IdCity=? AND xCoord = ? AND yCoord = ? ";
        String query2 = "SELECT * FROM City WHERE Id = ? ";
        String query3 = "INSERT INTO Address(Name, Number, xCoord, yCoord, IdCity) VALUES (?,?,?,?,?) ";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);
             PreparedStatement stmt3 = con.prepareStatement(query3, Statement.RETURN_GENERATED_KEYS);
        ) {
            stmt1.setInt(1, number);
            stmt1.setInt(2, cityId);
            stmt1.setInt(3, xCord);
            stmt1.setInt(4, yCord);
            ResultSet res1=stmt1.executeQuery();
            if(res1.next() == true) {
                return -1;
            }
            
            stmt2.setInt(1, cityId);
            ResultSet res2 = stmt2.executeQuery();
            if (res2.next() == false) {
                return -1;
            }
            
            stmt3.setString(1, name);
            stmt3.setInt(2, number);
            stmt3.setInt(3, xCord);
            stmt3.setInt(4, yCord);
            stmt3.setInt(5, cityId);
            int ret = 0; 
            stmt3.executeUpdate();
            ResultSet res3 = stmt3.getGeneratedKeys();
            if (res3.next()) {
                 ret = res3.getInt(1);
            }
            System.out.println("AddressRowId " + ret);
            return ret;
        } catch (SQLException ex) {
            Logger.getLogger(sd160457_AddressOperations.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
    }

    @Override
    public int deleteAddresses(String name, int number) {
        String query ="DELETE Address WHERE Name=? AND Number=?";
        
        try (PreparedStatement stmt=con.prepareStatement(query);) {
            stmt.setString(1, name);  
            stmt.setInt(2, number); 
            int ret = stmt.executeUpdate();
            return ret;
        } catch (SQLException ex) {
           Logger.getLogger(sd160457_AddressOperations.class.getName()).log(Level.SEVERE, null, ex);
           return 0;
        }
    }

    @Override
    public boolean deleteAdress(int idAddress) {
        String query ="DELETE Address WHERE Id=? ";
        
        try (PreparedStatement stmt=con.prepareStatement(query);) {
            stmt.setInt(1, idAddress);  
            int ret = stmt.executeUpdate();
            if(ret==0) {
               return false;
            } else {
               return true;
            }
        } catch (SQLException ex) {
           Logger.getLogger(sd160457_AddressOperations.class.getName()).log(Level.SEVERE, null, ex);
           return false;
        }
    }

    @Override
    public int deleteAllAddressesFromCity(int idCity) {
        String query ="DELETE Address WHERE IdCity=?";
        try (PreparedStatement ps=con.prepareStatement(query);) {
            ps.setInt(1, idCity);  
            int ret=ps.executeUpdate();
            return ret;
        } catch (SQLException ex) {
            Logger.getLogger(sd160457_AddressOperations.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }

    @Override
    public List<Integer> getAllAddressesFromCity(int idCity) {
        String query ="SELECT Id FROM Address WHERE IdCity=?";  
        
        try (PreparedStatement stmt=con.prepareStatement(query);) {
            List<Integer> ret = new ArrayList<>();
            
             stmt.setInt(1, idCity);
             ResultSet res = stmt.executeQuery();
             while(res.next()){
                 ret.add(res.getInt("Id"));
             }
             
             if (ret.size() > 0)
                 return ret;
         } catch (SQLException ex) {
             Logger.getLogger(sd160457_AddressOperations.class.getName()).log(Level.SEVERE, null, ex);
         }
         return null;
    }

    @Override
    public List<Integer> getAllAddresses() {
        String query ="SELECT Id FROM Address ";  
        
        List<Integer> ret = new ArrayList<>();
        try (PreparedStatement stmt=con.prepareStatement(query);) {
            ResultSet res = stmt.executeQuery();
            while(res.next()){
                ret.add(res.getInt("Id"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(sd160457_AddressOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ret;
    }
    
}
