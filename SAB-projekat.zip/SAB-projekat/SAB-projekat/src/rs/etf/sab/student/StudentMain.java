package rs.etf.sab.student;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javafx.util.Pair;
import rs.etf.sab.operations.*;
import rs.etf.sab.student.*;
import rs.etf.sab.tests.*;

public class StudentMain {
   

    public static void main(String[] args) {
        
        //initDB();
        
        AddressOperations addressOperations = new sd160457_AddressOperations(); // Change this to your implementation.
        CityOperations cityOperations = new sd160457_CityOperations(); // Do it for all classes.
        CourierOperations courierOperations = new sd160457_CourierOperations(); // e.g. = new MyDistrictOperations();
        CourierRequestOperation courierRequestOperation = new sd160457_CourierRequestOperation();
        DriveOperation driveOperation = new sd160457_DriveOperation();
        GeneralOperations generalOperations = new sd160457_GeneralOperations();
        PackageOperations packageOperations = new sd160457_PackageOperations();
        StockroomOperations stockroomOperations = new sd160457_StockroomOperations();
        UserOperations userOperations = new sd160457_UserOperations();
        VehicleOperations vehicleOperations = new sd160457_VehicleOperations();

        
        TestHandler.createInstance(
                addressOperations,
                cityOperations,
                courierOperations,
                courierRequestOperation,
                driveOperation,
                generalOperations,
                packageOperations,
                stockroomOperations,
                userOperations,
                vehicleOperations);

        TestRunner.runTests();
    }
    
    private static boolean initDB() {
        Connection con = DB.getInstance().getConnection();

        Integer[] fuelTypes = new Integer[]{0, 1, 2};
        Double[] fuelPrices = new Double[]{15.0, 32.0, 36.0};

        Integer[] packageInfoTypes = new Integer[]{0, 1, 2, 3};
        Double[] packageInfoInitialPrice = new Double[]{115.0, 175.0, 250.0, 350.0 };
        Double[] packageInfoPricePerKG = new Double[]{1.0, 100.0, 100.0, 500.0};

        try (PreparedStatement stmt = con.prepareCall("INSERT INTO Fuel(FuelType, Price) VALUES (?, ?)")) {
            for (int i = 0; i < fuelTypes.length; i++) {
                stmt.setInt(1, fuelTypes[i]);
                stmt.setDouble(2, fuelPrices[i]);

                if (stmt.executeUpdate() != 1) {
                    return false;
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        try (PreparedStatement stmt = con.prepareCall("INSERT INTO PackageInfo(PackageType, InitialPrice, Price) values (?,?,?)")) {
            for (int i = 0; i < packageInfoTypes.length; i++) {
                stmt.setInt(1, packageInfoTypes[i]);
                stmt.setDouble(2, packageInfoInitialPrice[i]);
                stmt.setDouble(3, packageInfoPricePerKG[i]);

                if (stmt.executeUpdate() != 1) {
                    return false;
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return true;
    }
}
