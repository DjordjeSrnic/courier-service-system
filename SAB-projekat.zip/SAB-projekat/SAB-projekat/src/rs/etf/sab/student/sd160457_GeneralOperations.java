/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import rs.etf.sab.operations.*;

/**
 *
 * @author Djordje
 */
public class sd160457_GeneralOperations implements GeneralOperations {

    @Override
    public void eraseAll() {
        Connection con = DB.getInstance().getConnection();
        String ops[] = {
            "DELETE FROM Delivered WHERE 1=1",
            "DELETE FROM Drove WHERE 1=1",
            "DELETE FROM Trunk WHERE 1=1",
            "DELETE FROM Stored WHERE 1=1",
            "DELETE FROM ToStock WHERE 1=1",
            "DELETE FROM ToDeliver WHERE 1=1",
            "DELETE FROM RejectedOffer WHERE 1=1",
            "DELETE FROM AcceptedOffer WHERE 1=1",
            "DELETE FROM Offer WHERE 1=1",
            "DELETE FROM Package WHERE 1=1",
            "DELETE FROM Drives WHERE 1=1",
            "DELETE FROM Courier WHERE 1=1",
            "DELETE FROM Parked WHERE 1=1",
            "DELETE FROM Stockroom WHERE 1=1",
            "DELETE FROM Request WHERE 1=1",
            "DELETE FROM Administrator WHERE 1=1",
            "DELETE FROM [User] WHERE 1=1",
            "DELETE FROM Address WHERE 1=1",
            "DELETE FROM City WHERE 1=1",
            "DELETE FROM Vehicle WHERE 1=1"
        };

        for (String op : ops) {
            try (PreparedStatement stmt = con.prepareStatement(op)) {
                stmt.executeUpdate();
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
    }
    
}
