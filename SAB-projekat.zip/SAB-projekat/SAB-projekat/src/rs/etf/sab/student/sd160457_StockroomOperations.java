/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.*;

/**
 *
 * @author Djordje
 */
public class sd160457_StockroomOperations implements StockroomOperations {

    private Connection con;
    
    public sd160457_StockroomOperations() {
        this.con = DB.getInstance().getConnection();
    }

    @Override
    public int insertStockroom(int address) {
        String query1 = "SELECT IdCity FROM Address WHERE Id=?";
        String query2 = "SELECT Id FROM Stockroom WHERE IdCity=?";
        String query3 = "INSERT INTO Stockroom(IdCity, IdAddress) VALUES(?,?)";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);
             PreparedStatement stmt3 = con.prepareStatement(query3, Statement.RETURN_GENERATED_KEYS);
        ){
            stmt1.setInt(1, address);
            ResultSet res1 = stmt1.executeQuery();
            if (res1.next() == false) {
                return -1;
            }
            
            int idCity = res1.getInt(1);
            
            stmt2.setInt(1, idCity);
            ResultSet res2 = stmt2.executeQuery();
            if (res2.next() == true) {
                return -1;
            }
            
            // Insert a city
            stmt3.setInt(1, idCity);
            stmt3.setInt(2, address);
            int ret = 0; 
            stmt3.executeUpdate();
            ResultSet res3 = stmt3.getGeneratedKeys();
            if (res3.next()) {
                 ret = res3.getInt(1);
            }
            System.out.println("StockroomRowId " + ret);
            return ret;
            
        } catch (SQLException e){
            Logger.getLogger(sd160457_StockroomOperations.class.getName()).log(Level.SEVERE, null, e);
        }
        return -1;
    }

    @Override
    public boolean deleteStockroom(int idStockroom) {
        String query1 = "SELECT * FROM Stored WHERE IdStockroom = ? ";
        String query2 = "SELECT * FROM Parked WHERE IdStockroom = ? ";
        String query3 = "DELETE Stockroom WHERE Id = ?";
        
        try(PreparedStatement stmt1 = con.prepareStatement(query1);
            PreparedStatement stmt2 = con.prepareStatement(query2);
            PreparedStatement stmt3 = con.prepareStatement(query3);) {
            
            stmt1.setInt(1, idStockroom);
            ResultSet rs1 = stmt1.executeQuery();
            if (rs1.next() == true)
                return false;
            
            stmt2.setInt(1, idStockroom);
            ResultSet rs2 = stmt2.executeQuery();
            if (rs2.next() == true)
                return false;
            
            stmt3.setInt(1, idStockroom);
            int ret = stmt3.executeUpdate();
            if (ret == 0) 
                return false;
            else 
                return true;
        } catch (SQLException e) {
            Logger.getLogger(sd160457_StockroomOperations.class.getName()).log(Level.SEVERE, null, e);
        }
        return false;
    }

    @Override
    public int deleteStockroomFromCity(int idCity) {
        String query1 = "SELECT * FROM Stockroom WHERE IdCity = ? ";
        String query2 = "SELECT * FROM Stored WHERE IdStockroom = ? ";
        String query3 = "SELECT * FROM Parked WHERE IdStockroom = ? ";
        String query4 = "DELETE Stockroom WHERE Id = ? ";
        
        try(PreparedStatement stmt1 = con.prepareStatement(query1);
            PreparedStatement stmt2 = con.prepareStatement(query2);
            PreparedStatement stmt3 = con.prepareStatement(query3);
            PreparedStatement stmt4 = con.prepareStatement(query4);) {
            
            int idStockroom = -1;
            stmt1.setInt(1, idCity);
            ResultSet rs1 = stmt1.executeQuery();
            if (rs1.next() == false) {
                return -1;
            } else {
                idStockroom = rs1.getInt("Id");
            }
            
            stmt2.setInt(1, idStockroom);
            ResultSet rs2 = stmt2.executeQuery();
            if (rs2.next() == true) {
                return -1;
            }
            
            stmt3.setInt(1, idStockroom);
            ResultSet rs3 = stmt3.executeQuery();
            if (rs3.next() == true) {
                return -1;
            }
            
            stmt4.setInt(1, idStockroom);
            stmt4.executeUpdate();
            
            return idStockroom;
        } catch (SQLException e) {
            Logger.getLogger(sd160457_StockroomOperations.class.getName()).log(Level.SEVERE, null, e);
        }
        return -1;
    }

    @Override
    public List<Integer> getAllStockrooms() {
        String query ="SELECT * FROM Stockroom ";  
        
        List<Integer> ret = new ArrayList<>();
        try (PreparedStatement stmt=con.prepareStatement(query);){
             ResultSet res=stmt.executeQuery();
             while(res.next()){
                 ret.add(res.getInt("Id"));
             }
             return ret;
         } catch (SQLException e) {
             Logger.getLogger(sd160457_StockroomOperations.class.getName()).log(Level.SEVERE, null, e);
         }
         return null;
    }
    
}
