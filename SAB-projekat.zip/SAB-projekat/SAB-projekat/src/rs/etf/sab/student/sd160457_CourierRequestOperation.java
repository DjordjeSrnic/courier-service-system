/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.*;

/**
 *
 * @author Djordje
 */
public class sd160457_CourierRequestOperation implements CourierRequestOperation {

    private Connection con;

    public sd160457_CourierRequestOperation() {
        this.con = DB.getInstance().getConnection();
    }

    @Override
    public boolean insertCourierRequest(String userName, String driverLicenceNumber) {
        String query1 = "SELECT * FROM Courier WHERE Username = ?";
        String query2 = "SELECT * FROM Courier WHERE LicenceNumber = ?";
        String query3 = "SELECT * FROM [User] WHERE Username = ?";
        String query4 = "SELECT * FROM Request WHERE Username = ?";
        String query5 = "SELECT * FROM Request WHERE LicenceNumber = ?";
        String query6 = "INSERT INTO Request(Username, LicenceNumber) VALUES (?,?)";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);
             PreparedStatement stmt3 = con.prepareStatement(query3);
             PreparedStatement stmt4 = con.prepareStatement(query4);
             PreparedStatement stmt5 = con.prepareStatement(query5);
             PreparedStatement stmt6 = con.prepareStatement(query6);
        ) {
            stmt1.setString(1, userName);
            ResultSet res1 = stmt1.executeQuery();
            if (res1.next() == true) {
                return false;
            }
            
            stmt2.setString(1, userName);
            ResultSet res2 = stmt2.executeQuery();
            if (res2.next() == true) {
                return false;
            }
            
            stmt3.setString(1, userName);
            ResultSet res3 = stmt3.executeQuery();
            if (res3.next() == false) {
                return false;
            }
            
            stmt4.setString(1, userName);
            ResultSet res4 = stmt4.executeQuery();
            if (res4.next() == true) {
                return false;
            }
            
            stmt5.setString(1, driverLicenceNumber);
            ResultSet res5 = stmt5.executeQuery();
            if (res5.next() == true) {
                return false;
            }
            
            stmt6.setString(1, userName);
            stmt6.setString(2, driverLicenceNumber);
            int ret = stmt6.executeUpdate();
            
            if (ret == 1) {
                System.out.println("RequestRowId");
                return true;
            } else
                return false;
        } catch (SQLException e) {
            Logger.getLogger(sd160457_CourierRequestOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return false;
    }

    @Override
    public boolean deleteCourierRequest(String userName) {
        String query = "DELETE FROM Request WHERE Username = ?";
        
        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setString(1, userName);

            int ret = stmt.executeUpdate();
            if (ret == 1) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_CourierRequestOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return false;
    }

    @Override
    public boolean changeDriverLicenceNumberInCourierRequest(String userName, String drivingLicenceNumber) {
        String query = "UPDATE Request SET LicenceNumber = ? WHERE Username = ?";
        
        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setString(1, drivingLicenceNumber);
            stmt.setString(2, userName);
            int ret = stmt.executeUpdate();
            if (ret == 1) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_CourierRequestOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return false;
    }

    @Override
    public List<String> getAllCourierRequests() {
        String query = "SELECT Username FROM Request";

        List<String> ret = new ArrayList<>();
        try (PreparedStatement stmt = con.prepareStatement(query);) {
            ResultSet res = stmt.executeQuery();
            while (res.next()) {
                ret.add(res.getString("Username"));
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_CourierRequestOperation.class.getName()).log(Level.SEVERE, null, e);
        }
        
        return ret;
    }

    @Override
    public boolean grantRequest(String userName) {
        String call = "{ ? = CALL PR_Grant_Request(?) }";
        try (CallableStatement proc = con.prepareCall(call)) {
            proc.registerOutParameter(1, Types.INTEGER);
            proc.setString(2, userName);
            proc.execute();
            if (proc.getInt(1) == 1) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_CourierRequestOperation.class.getName()).log(Level.SEVERE, null, e);
        }

        return false;
    }

}
