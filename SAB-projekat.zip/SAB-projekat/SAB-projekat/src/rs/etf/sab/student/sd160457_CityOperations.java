/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.*;

/**
 *
 * @author Djordje
 */
public class sd160457_CityOperations implements CityOperations {
    
    public sd160457_CityOperations() {
    }
    
    @Override
    public int insertCity(String name, String postalCode) {
        //System.out.println("INSERT NAME: " + name + " POSTAL: " + postalCode);
        String query1 = "SELECT Id FROM City WHERE Name = ?";
        String query2 = "SELECT Id FROM City WHERE PostalCode = ?";
        String query3 = "INSERT INTO City(Name, PostalCode) VALUES (?,?)";
        
        Connection con = DB.getInstance().getConnection();
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);
             PreparedStatement stmt3 = con.prepareStatement(query3, Statement.RETURN_GENERATED_KEYS);
        ){
            
            
            stmt2.setString(1, postalCode);
            ResultSet res2 = stmt2.executeQuery();
            if (res2.next())
                return -1;
            
            // Insert a city
            stmt3.setString(1, name);
            stmt3.setString(2, postalCode);
            int ret = 0; 
            if (stmt3.executeUpdate() == 0) {
                return -1;
            }
            ResultSet res3 = stmt3.getGeneratedKeys();
            if (res3.next()) {
                 ret = res3.getInt(1);
            }
            System.out.println("CityRowId " + ret);
            return ret;
            
        } catch (SQLException e){
            Logger.getLogger(sd160457_CityOperations.class.getName()).log(Level.SEVERE, null, e);
        }
        return -1;
    }

    @Override
    public int deleteCity(String... names) {
        
        String query ="DELETE City WHERE Name=?";
        
        Connection con = DB.getInstance().getConnection();
        try (PreparedStatement stmt=con.prepareStatement(query);) {
             int ret=0;
             for(String name: names){
                //System.out.println("DELETE NAME " + name);
                stmt.setString(1, name);
                ret+=stmt.executeUpdate();
             }
             //System.out.println("TOTAL DELETED: " + ret);
             return ret;
         } catch (SQLException e) {
             Logger.getLogger(sd160457_CityOperations.class.getName()).log(Level.SEVERE, null, e);
             return 0;
         }
    }

    @Override
    public boolean deleteCity(int idCity) {
        //System.out.println("DELETE ID " + idCity);
        String query = "DELETE City WHERE Id = ?";
        
        Connection con = DB.getInstance().getConnection();
        try(PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, idCity);
            int ret = stmt.executeUpdate();
            if (ret == 0) {
                //System.out.println("Unsuccessful delete " + idCity);
                return false;
            } else {
                //System.out.println("Successful delete " + idCity);
                return true;
            }
        } catch (SQLException e) {
            Logger.getLogger(sd160457_CityOperations.class.getName()).log(Level.SEVERE, null, e);
        }
        return false;
    }

    @Override
    public List<Integer> getAllCities() {
        //System.out.println("GET ALL");
        String query ="SELECT * FROM City";  
        
        List<Integer> ret = new ArrayList<>();
        Connection con = DB.getInstance().getConnection();
        try (PreparedStatement stmt=con.prepareStatement(query);){
             ResultSet res=stmt.executeQuery();
             while(res.next()){
                 //System.out.println("CITY ID " + res.getInt("Id"));
                 ret.add(res.getInt("Id"));
             }
         } catch (SQLException e) {
             Logger.getLogger(sd160457_CityOperations.class.getName()).log(Level.SEVERE, null, e);
         }
         return ret;
    }
    
}
