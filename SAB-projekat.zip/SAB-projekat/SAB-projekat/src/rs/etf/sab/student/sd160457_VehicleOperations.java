/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.*;

/**
 *
 * @author Djordje
 */
public class sd160457_VehicleOperations implements VehicleOperations {

    private Connection con;
    
    public sd160457_VehicleOperations() {
        this.con = DB.getInstance().getConnection();
    }

    @Override
    public boolean insertVehicle(String licensePlateNumber, int fuelType, BigDecimal fuelConsumtion, BigDecimal capacity) {
        String query1 = "SELECT * FROM Vehicle WHERE LicencePlate=?";
        String query2 = "INSERT INTO Vehicle(LicencePlate, FuelType, Capacity, FuelConsumption, Load) VALUES(?,?,?,?,?)";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);) {
            
            stmt1.setString(1, licensePlateNumber);
            ResultSet res1 = stmt1.executeQuery();
            
            if (res1.next() == true) {
                System.out.println("Vehicle with that licence plate number already exists.");
                return false;
            }
            
            BigDecimal cap = capacity.setScale(3, BigDecimal.ROUND_HALF_UP);
            BigDecimal cons = fuelConsumtion.setScale(3, BigDecimal.ROUND_HALF_UP);
            stmt2.setString(1, licensePlateNumber);
            stmt2.setInt(2, fuelType);
            stmt2.setBigDecimal(3, cap);
            stmt2.setBigDecimal(4, cons);
            stmt2.setInt(5, 0);
            int res=stmt2.executeUpdate();
            if(res==0) 
                return false;
            else {
                System.out.println("VehicleRowId");
                return true;
            }
         } catch (SQLException ex) {
             Logger.getLogger(sd160457_VehicleOperations.class.getName()).log(Level.SEVERE, null, ex);
             return false;
         }
    }

    @Override
    public int deleteVehicles(String... licencePlateNumbers) {
        String query1 = "SELECT * FROM Drives WHERE LicencePlate=?";
        String query2 = "DELETE Parked WHERE LicencePlate=?";
        String query3 = "DELETE Vehicle WHERE LicencePlate=?";
        
         try (PreparedStatement stmt1 = con.prepareStatement(query1);
              PreparedStatement stmt2 = con.prepareStatement(query2);
              PreparedStatement stmt3 = con.prepareStatement(query3);) {
             int ret=0;
             for(String plate: licencePlateNumbers){
                stmt1.setString(1, plate);
                ResultSet rs1 = stmt1.executeQuery();
                
                if (rs1.next() == false) {
                    stmt2.setString(1, plate);
                    stmt2.executeUpdate();

                    stmt3.setString(1, plate);
                    ret += stmt3.executeUpdate();
                }
             }
             return ret;
         } catch (SQLException ex) {
             Logger.getLogger(sd160457_VehicleOperations.class.getName()).log(Level.SEVERE, null, ex);
             return 0;
         }
    }

    @Override
    public List<String> getAllVehichles() {
        String query ="SELECT * FROM Vehicle ";  
        
        List<String> ret = new ArrayList();
        try (PreparedStatement stmt = con.prepareStatement(query);) {
             ResultSet res=stmt.executeQuery();
             while(res.next()){
                 ret.add(res.getString("LicencePlate"));
             }
         } catch (SQLException ex) {
             Logger.getLogger(sd160457_VehicleOperations.class.getName()).log(Level.SEVERE, null, ex);
         }
         return ret;
    }

    @Override
    public boolean changeFuelType(String licensePlateNumber, int fuelType) {
        String query1 = "SELECT * FROM Parked WHERE LicencePlate=? ";
        String query2 = "UPDATE Vehicle SET FuelType=? WHERE LicencePlate=? ";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);) {
            if(fuelType<0 || fuelType>2) 
                return false;

            stmt1.setString(1, licensePlateNumber);
            ResultSet rs1 = stmt1.executeQuery();
            if (rs1.next() == false)
                return false;
            
            stmt2.setInt(1, fuelType);
            stmt2.setString(2, licensePlateNumber);
            int ret = stmt2.executeUpdate();
            
            if(ret==1) 
                return true;
            else 
                return false;
        } catch (SQLException ex) {
            Logger.getLogger(sd160457_VehicleOperations.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    @Override
    public boolean changeConsumption(String licensePlateNumber, BigDecimal fuelConsumption) {
        String query1 = "SELECT * FROM Parked WHERE LicencePlate=? ";
        String query2 = "UPDATE Vehicle SET FuelConsumption=? WHERE LicencePlate=? ";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);) {
            
            stmt1.setString(1, licensePlateNumber);
            ResultSet rs1 = stmt1.executeQuery();
            if (rs1.next() == false)
                return false;
            
            BigDecimal cons = fuelConsumption.setScale(3, BigDecimal.ROUND_HALF_UP);
            stmt2.setBigDecimal(1, cons);
            stmt2.setString(2, licensePlateNumber);
            int ret=stmt2.executeUpdate();
            if(ret==1) 
                return true;
            else 
                return false;
         } catch (SQLException ex) {
             Logger.getLogger(sd160457_VehicleOperations.class.getName()).log(Level.SEVERE, null, ex);
             return false;
         }
    }

    @Override
    public boolean changeCapacity(String licensePlateNumber, BigDecimal capacity) {
        String query1 = "SELECT * FROM Parked WHERE LicencePlate=? ";
        String query2 = "UPDATE Vehicle SET Capacity=? WHERE LicencePlate=? ";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);) {
            
            stmt1.setString(1, licensePlateNumber);
            ResultSet rs1 = stmt1.executeQuery();
            if (rs1.next() == false)
                return false;
            
            BigDecimal cap = capacity.setScale(3, BigDecimal.ROUND_HALF_UP);
            stmt2.setBigDecimal(1, cap);
            stmt2.setString(2, licensePlateNumber);
            int ret=stmt2.executeUpdate();
            if(ret==1) 
                return true;
            else 
                return false;
         } catch (SQLException ex) {
             Logger.getLogger(sd160457_VehicleOperations.class.getName()).log(Level.SEVERE, null, ex);
             return false;
         }
    }

    @Override
    public boolean parkVehicle(String licencePlateNumber, int idStockroom) {
        String query1 = "SELECT * FROM Vehicle WHERE LicencePlate = ?";
        String query2 = "SELECT * FROM Stockroom WHERE Id = ?";
        String query3 = "SELECT C.Status FROM Courier C INNER JOIN "
                + "Drives D ON C.Username = D.Username "
                + "WHERE D.LicencePlate = ?";
        String query4 = "INSERT INTO Parked(LicencePlate, IdStockroom) "
                + "VALUES(?,?) ";
        
        try (PreparedStatement stmt1 = con.prepareStatement(query1);
             PreparedStatement stmt2 = con.prepareStatement(query2);
             PreparedStatement stmt3 = con.prepareStatement(query3);
             PreparedStatement stmt4 = con.prepareStatement(query4);) {
            
            stmt1.setString(1, licencePlateNumber);
            ResultSet rs1 = stmt1.executeQuery();
            if (rs1.next() == false)
                return false;
            
            stmt2.setInt(1, idStockroom);
            ResultSet rs2 = stmt2.executeQuery();
            if (rs2.next() == false)
                return false;
            
            stmt3.setString(1, licencePlateNumber);
            ResultSet rs3 = stmt3.executeQuery();
            
            if (rs3.next() == true) {
                int status = rs3.getInt(1);
                if (status == 1)
                    return false;
            }
            
            stmt4.setString(1, licencePlateNumber);
            stmt4.setInt(2, idStockroom);
            int ret=stmt4.executeUpdate();
            if(ret==1) 
                return true;
            else 
                return false;
         } catch (SQLException ex) {
             Logger.getLogger(sd160457_VehicleOperations.class.getName()).log(Level.SEVERE, null, ex);
             return false;
         }
    }
    
}
