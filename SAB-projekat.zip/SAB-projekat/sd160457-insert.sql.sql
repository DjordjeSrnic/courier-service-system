CREATE DATABASE CourierService
go

USE CourierService
go

CREATE TABLE [AcceptedOffer]
( 
	[IdOffer]            integer  NOT NULL ,
	[AcceptedTime]       DATETIME  NULL 
)
go

ALTER TABLE [AcceptedOffer]
	ADD CONSTRAINT [XPKAcceptedOffer] PRIMARY KEY  CLUSTERED ([IdOffer] ASC)
go

CREATE TABLE [Address]
( 
	[Id]                 integer  NOT NULL  IDENTITY ,
	[Name]               varchar(100)  NULL ,
	[xCoord]             integer  NULL ,
	[yCoord]             integer  NULL ,
	[IdCity]             integer  NULL ,
	[Number]             integer  NULL 
)
go

ALTER TABLE [Address]
	ADD CONSTRAINT [XPKAddress] PRIMARY KEY  CLUSTERED ([Id] ASC)
go

CREATE TABLE [Administrator]
( 
	[Username]           varchar(100)  NOT NULL 
)
go

ALTER TABLE [Administrator]
	ADD CONSTRAINT [XPKAdministrator] PRIMARY KEY  CLUSTERED ([Username] ASC)
go

CREATE TABLE [City]
( 
	[Id]                 integer  NOT NULL  IDENTITY ,
	[Name]               varchar(100)  NULL ,
	[PostalCode]         varchar(100)  NULL 
)
go

ALTER TABLE [City]
	ADD CONSTRAINT [XPKCity] PRIMARY KEY  CLUSTERED ([Id] ASC)
go

CREATE TABLE [Courier]
( 
	[Username]           varchar(100)  NOT NULL ,
	[NumDeliveries]      integer  NULL ,
	[Profit]             decimal(10,3)  NULL ,
	[Status]             integer  NULL 
	CONSTRAINT [DriveStatusConstraint_1734972074]
		CHECK  ( [Status]=0 OR [Status]=1 ),
	[LicenceNumber]      varchar(100)  NULL 
)
go

ALTER TABLE [Courier]
	ADD CONSTRAINT [XPKCourier] PRIMARY KEY  CLUSTERED ([Username] ASC)
go

CREATE TABLE [Delivered]
( 
	[IdPackage]          integer  NOT NULL ,
	[Username]           varchar(100)  NULL 
)
go

ALTER TABLE [Delivered]
	ADD CONSTRAINT [XPKDelivered] PRIMARY KEY  CLUSTERED ([IdPackage] ASC)
go

CREATE TABLE [Drives]
( 
	[Username]           varchar(100)  NOT NULL ,
	[LicencePlate]       varchar(100)  NULL ,
	[TravelDistance]     decimal(10,3)  NULL ,
	[IdAddress]          integer  NULL 
)
go

ALTER TABLE [Drives]
	ADD CONSTRAINT [XPKDrives] PRIMARY KEY  CLUSTERED ([Username] ASC)
go

CREATE TABLE [Drove]
( 
	[LicencePlate]       varchar(100)  NOT NULL ,
	[Username]           varchar(100)  NULL 
)
go

ALTER TABLE [Drove]
	ADD CONSTRAINT [XPKDrove] PRIMARY KEY  CLUSTERED ([LicencePlate] ASC)
go

CREATE TABLE [Fuel]
( 
	[FuelType]           integer  NOT NULL 
	CONSTRAINT [FuelTypeConstraint_521362776]
		CHECK  ( [FuelType]=0 OR [FuelType]=1 OR [FuelType]=2 ),
	[Price]              decimal(10,3)  NULL 
)
go

ALTER TABLE [Fuel]
	ADD CONSTRAINT [XPKFuel] PRIMARY KEY  CLUSTERED ([FuelType] ASC)
go

CREATE TABLE [Offer]
( 
	[Id]                 integer  NOT NULL  IDENTITY ,
	[IdPackage]          integer  NULL 
)
go

ALTER TABLE [Offer]
	ADD CONSTRAINT [XPKOffer] PRIMARY KEY  CLUSTERED ([Id] ASC)
go

CREATE TABLE [Package]
( 
	[Id]                 integer  NOT NULL  IDENTITY ,
	[Weight]             decimal(10,3)  NULL ,
	[Price]              decimal(10,3)  NULL ,
	[Status]             integer  NULL 
	CONSTRAINT [PackageStatusConstraint_1650422329]
		CHECK  ( [Status]=0 OR [Status]=1 OR [Status]=2 OR [Status]=3 OR [Status]=4 ),
	[AddressFrom]        integer  NULL ,
	[AddressTo]          integer  NULL ,
	[PackageType]        integer  NULL ,
	[Sender]             varchar(100)  NULL 
)
go

ALTER TABLE [Package]
	ADD CONSTRAINT [XPKPackage] PRIMARY KEY  CLUSTERED ([Id] ASC)
go

CREATE TABLE [PackageInfo]
( 
	[PackageType]        integer  NOT NULL 
	CONSTRAINT [PackageTypeConstraint_379305096]
		CHECK  ( [PackageType]=0 OR [PackageType]=1 OR [PackageType]=2 OR [PackageType]=3 ),
	[InitialPrice]       decimal(10,3)  NULL ,
	[WeightFactor]       decimal(10,3)  NULL ,
	[Price]              decimal(10,3)  NULL 
)
go

ALTER TABLE [PackageInfo]
	ADD CONSTRAINT [XPKPackageInfo] PRIMARY KEY  CLUSTERED ([PackageType] ASC)
go

CREATE TABLE [Parked]
( 
	[IdStockroom]        integer  NULL ,
	[LicencePlate]       varchar(100)  NOT NULL 
)
go

ALTER TABLE [Parked]
	ADD CONSTRAINT [XPKParked] PRIMARY KEY  CLUSTERED ([LicencePlate] ASC)
go

CREATE TABLE [RejectedOffer]
( 
	[IdOffer]            integer  NOT NULL 
)
go

ALTER TABLE [RejectedOffer]
	ADD CONSTRAINT [XPKRejectedOffer] PRIMARY KEY  CLUSTERED ([IdOffer] ASC)
go

CREATE TABLE [Request]
( 
	[Username]           varchar(100)  NOT NULL ,
	[LicenceNumber]      varchar(100)  NULL 
)
go

ALTER TABLE [Request]
	ADD CONSTRAINT [XPKRequest] PRIMARY KEY  CLUSTERED ([Username] ASC)
go

CREATE TABLE [Stockroom]
( 
	[IdCity]             integer  NOT NULL ,
	[IdAddress]          integer  NOT NULL ,
	[Id]                 integer  NOT NULL  IDENTITY 
)
go

ALTER TABLE [Stockroom]
	ADD CONSTRAINT [XPKStockroom] PRIMARY KEY  CLUSTERED ([Id] ASC)
go

CREATE TABLE [Stored]
( 
	[IdPackage]          integer  NOT NULL ,
	[IdStockroom]        integer  NOT NULL 
)
go

ALTER TABLE [Stored]
	ADD CONSTRAINT [XPKStored] PRIMARY KEY  CLUSTERED ([IdPackage] ASC)
go

CREATE TABLE [ToDeliver]
( 
	[IdPackage]          integer  NOT NULL ,
	[Username]           varchar(100)  NULL ,
	[IdAddress]          integer  NULL 
)
go

ALTER TABLE [ToDeliver]
	ADD CONSTRAINT [XPKToDeliver] PRIMARY KEY  CLUSTERED ([IdPackage] ASC)
go

CREATE TABLE [ToStock]
( 
	[IdPackage]          integer  NOT NULL ,
	[Username]           varchar(100)  NULL 
)
go

ALTER TABLE [ToStock]
	ADD CONSTRAINT [XPKToStock] PRIMARY KEY  CLUSTERED ([IdPackage] ASC)
go

CREATE TABLE [Trunk]
( 
	[LicencePlate]       varchar(100)  NOT NULL ,
	[IdPackage]          integer  NOT NULL ,
	[Type]               integer  NULL 
)
go

ALTER TABLE [Trunk]
	ADD CONSTRAINT [XPKTrunk] PRIMARY KEY  CLUSTERED ([IdPackage] ASC)
go

CREATE TABLE [User]
( 
	[Username]           varchar(100)  NOT NULL ,
	[Name]               varchar(100)  NULL ,
	[Surname]            varchar(100)  NULL ,
	[Password]           varchar(100)  NULL ,
	[IdAddress]          integer  NULL ,
	[NumSent]            integer  NULL 
)
go

ALTER TABLE [User]
	ADD CONSTRAINT [XPKUser] PRIMARY KEY  CLUSTERED ([Username] ASC)
go

CREATE TABLE [Vehicle]
( 
	[LicencePlate]       varchar(100)  NOT NULL ,
	[FuelConsumption]    decimal(10,3)  NULL ,
	[Capacity]           decimal(10,3)  NULL ,
	[Load]               decimal(10,3)  NULL ,
	[FuelType]           integer  NULL 
)
go

ALTER TABLE [Vehicle]
	ADD CONSTRAINT [XPKVehicle] PRIMARY KEY  CLUSTERED ([LicencePlate] ASC)
go


ALTER TABLE [AcceptedOffer]
	ADD CONSTRAINT [R_24] FOREIGN KEY ([IdOffer]) REFERENCES [Offer]([Id])
		ON DELETE CASCADE
		ON UPDATE CASCADE
go


ALTER TABLE [Address]
	ADD CONSTRAINT [R_9] FOREIGN KEY ([IdCity]) REFERENCES [City]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [Administrator]
	ADD CONSTRAINT [R_4] FOREIGN KEY ([Username]) REFERENCES [User]([Username])
		ON DELETE CASCADE
		ON UPDATE CASCADE
go


ALTER TABLE [Courier]
	ADD CONSTRAINT [R_5] FOREIGN KEY ([Username]) REFERENCES [User]([Username])
		ON DELETE CASCADE
		ON UPDATE CASCADE
go


ALTER TABLE [Delivered]
	ADD CONSTRAINT [R_36] FOREIGN KEY ([IdPackage]) REFERENCES [Package]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [Delivered]
	ADD CONSTRAINT [R_37] FOREIGN KEY ([Username]) REFERENCES [Courier]([Username])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [Drives]
	ADD CONSTRAINT [R_6] FOREIGN KEY ([Username]) REFERENCES [Courier]([Username])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [Drives]
	ADD CONSTRAINT [R_7] FOREIGN KEY ([LicencePlate]) REFERENCES [Vehicle]([LicencePlate])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [Drives]
	ADD CONSTRAINT [R_34] FOREIGN KEY ([IdAddress]) REFERENCES [Address]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [Drove]
	ADD CONSTRAINT [R_38] FOREIGN KEY ([LicencePlate]) REFERENCES [Vehicle]([LicencePlate])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [Drove]
	ADD CONSTRAINT [R_39] FOREIGN KEY ([Username]) REFERENCES [User]([Username])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [Offer]
	ADD CONSTRAINT [R_23] FOREIGN KEY ([IdPackage]) REFERENCES [Package]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [Package]
	ADD CONSTRAINT [R_15] FOREIGN KEY ([AddressFrom]) REFERENCES [Address]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [Package]
	ADD CONSTRAINT [R_16] FOREIGN KEY ([AddressTo]) REFERENCES [Address]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [Package]
	ADD CONSTRAINT [R_22] FOREIGN KEY ([PackageType]) REFERENCES [PackageInfo]([PackageType])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [Package]
	ADD CONSTRAINT [R_33] FOREIGN KEY ([Sender]) REFERENCES [User]([Username])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [Parked]
	ADD CONSTRAINT [R_13] FOREIGN KEY ([IdStockroom]) REFERENCES [Stockroom]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [Parked]
	ADD CONSTRAINT [R_14] FOREIGN KEY ([LicencePlate]) REFERENCES [Vehicle]([LicencePlate])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [RejectedOffer]
	ADD CONSTRAINT [R_25] FOREIGN KEY ([IdOffer]) REFERENCES [Offer]([Id])
		ON DELETE CASCADE
		ON UPDATE CASCADE
go


ALTER TABLE [Request]
	ADD CONSTRAINT [R_31] FOREIGN KEY ([Username]) REFERENCES [User]([Username])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [Stockroom]
	ADD CONSTRAINT [R_10] FOREIGN KEY ([IdCity]) REFERENCES [City]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [Stockroom]
	ADD CONSTRAINT [R_12] FOREIGN KEY ([IdAddress]) REFERENCES [Address]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [Stored]
	ADD CONSTRAINT [R_17] FOREIGN KEY ([IdPackage]) REFERENCES [Package]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [Stored]
	ADD CONSTRAINT [R_18] FOREIGN KEY ([IdStockroom]) REFERENCES [Stockroom]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [ToDeliver]
	ADD CONSTRAINT [R_28] FOREIGN KEY ([IdPackage]) REFERENCES [Package]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [ToDeliver]
	ADD CONSTRAINT [R_29] FOREIGN KEY ([Username]) REFERENCES [Courier]([Username])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [ToDeliver]
	ADD CONSTRAINT [R_35] FOREIGN KEY ([IdAddress]) REFERENCES [Address]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [ToStock]
	ADD CONSTRAINT [R_26] FOREIGN KEY ([IdPackage]) REFERENCES [Package]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [ToStock]
	ADD CONSTRAINT [R_27] FOREIGN KEY ([Username]) REFERENCES [Courier]([Username])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [Trunk]
	ADD CONSTRAINT [R_19] FOREIGN KEY ([LicencePlate]) REFERENCES [Vehicle]([LicencePlate])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [Trunk]
	ADD CONSTRAINT [R_20] FOREIGN KEY ([IdPackage]) REFERENCES [Package]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [User]
	ADD CONSTRAINT [R_30] FOREIGN KEY ([IdAddress]) REFERENCES [Address]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [Vehicle]
	ADD CONSTRAINT [R_3] FOREIGN KEY ([FuelType]) REFERENCES [Fuel]([FuelType])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go
